
from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "trading.db"

MIGRATION_SQL = """
CREATE TABLE IF NOT EXISTS position_risk_state (
    position_id INTEGER PRIMARY KEY,
    peak_pnl_pct REAL NOT NULL DEFAULT 0,
    break_even_armed INTEGER NOT NULL DEFAULT 0,
    active_stop_pct REAL NOT NULL DEFAULT -20,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(position_id) REFERENCES positions(id)
);

CREATE INDEX IF NOT EXISTS idx_position_risk_break_even
ON position_risk_state(break_even_armed, peak_pnl_pct DESC);
"""


def table_exists(
    connection: sqlite3.Connection,
    table_name: str,
) -> bool:
    return connection.execute(
        """
        SELECT 1
        FROM sqlite_master
        WHERE type = 'table' AND name = ?
        """,
        (table_name,),
    ).fetchone() is not None


def write_state(
    connection: sqlite3.Connection,
    key: str,
    value: str,
) -> None:
    connection.execute(
        """
        INSERT INTO bot_state(key, value, updated_at)
        VALUES (?, ?, datetime('now'))
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value),
    )


def main() -> None:
    if not DB_PATH.exists():
        print("Aucune base existante à migrer.")
        return

    with sqlite3.connect(DB_PATH, timeout=20) as connection:
        connection.execute("PRAGMA busy_timeout=10000")
        already_v10_1 = table_exists(
            connection,
            "position_risk_state",
        )
        if table_exists(connection, "bot_state"):
            version_row = connection.execute(
                """
                SELECT value
                FROM bot_state
                WHERE key = 'strategy_version'
                """
            ).fetchone()
            already_v10_1 = (
                already_v10_1
                and version_row is not None
                and version_row[0] == "strategy_engine_v10_1"
            )

        if already_v10_1:
            print("Base déjà compatible avec SOLPULSE V10.1.")
            return

        connection.execute("PRAGMA wal_checkpoint(FULL)")
        connection.commit()

    backup = DB_PATH.with_name(
        "trading-before-v10-1-"
        + datetime.now().strftime("%Y%m%d-%H%M%S")
        + ".db"
    )

    # One timestamped safety backup, only for the actual migration.
    shutil.copy2(DB_PATH, backup)

    with sqlite3.connect(DB_PATH, timeout=20) as connection:
        connection.execute("PRAGMA busy_timeout=10000")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.executescript(MIGRATION_SQL)

        if table_exists(connection, "positions"):
            connection.execute(
                """
                INSERT OR IGNORE INTO position_risk_state (
                    position_id, peak_pnl_pct,
                    break_even_armed, active_stop_pct,
                    updated_at
                )
                SELECT
                    id,
                    CASE
                        WHEN entry_sol + COALESCE(entry_fees_sol, 0) > 0
                        THEN (
                            COALESCE(current_value_sol, entry_sol)
                            - entry_sol
                            - COALESCE(entry_fees_sol, 0)
                        ) / (
                            entry_sol
                            + COALESCE(entry_fees_sol, 0)
                        ) * 100.0
                        ELSE 0
                    END,
                    0,
                    -20,
                    datetime('now')
                FROM positions
                WHERE status = 'OPEN'
                """
            )

        if table_exists(connection, "bot_state"):
            write_state(
                connection,
                "strategy_version",
                "strategy_engine_v10_1",
            )
            write_state(
                connection,
                "strategy_rules",
                "holder max 3.5% total supply; pool ignored; 1 position; 0.05 SOL; SL -20%; TP +100%; BE after +50%",
            )
            write_state(
                connection,
                "position_risk_status",
                "READY",
            )
            write_state(
                connection,
                "holder_denominator",
                "TOTAL_SUPPLY",
            )
            write_state(
                connection,
                "pool_holder_rule",
                "IGNORED",
            )

        connection.commit()
        integrity = connection.execute(
            "PRAGMA integrity_check"
        ).fetchone()[0]

    print("=" * 68)
    print("MIGRATION SOLPULSE V10.1")
    print("=" * 68)
    print(f"Base migrée : {DB_PATH}")
    print(f"Sauvegarde : {backup.name}")
    print(f"Intégrité : {integrity}")


if __name__ == "__main__":
    main()


from __future__ import annotations

import json
import math
import os
import sqlite3
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "trading.db"
CONFIG_PATH = BASE_DIR / "config.json"
LOCK_PATH = BASE_DIR / "data" / "safety_engine.lock"

DEXSCREENER_BASE_URL = "https://api.dexscreener.com"
TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"

running = True


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def now_iso() -> str:
    return now_utc().isoformat()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def to_float(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def connect_db() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=5000")
    return connection


def write_state(
    connection: sqlite3.Connection,
    key: str,
    value: str,
) -> None:
    connection.execute(
        """
        INSERT INTO bot_state(key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now_iso()),
    )


def acquire_lock() -> None:
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)

    if LOCK_PATH.exists():
        age = time.time() - LOCK_PATH.stat().st_mtime
        if age < 30:
            print("Le Safety Engine semble déjà fonctionner.")
            sys.exit(1)
        LOCK_PATH.unlink(missing_ok=True)

    LOCK_PATH.write_text(str(os.getpid()), encoding="utf-8")


def release_lock() -> None:
    LOCK_PATH.unlink(missing_ok=True)


def rpc_call(
    client: httpx.Client,
    method: str,
    params: list[Any],
) -> Any:
    response = client.post(
        "",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        },
        headers={"Content-Type": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()

    if payload.get("error"):
        raise RuntimeError(f"{method}: {payload['error']}")

    return payload.get("result")


def parsed_account_info(
    account: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not account:
        return None

    data = account.get("data")
    if not isinstance(data, dict):
        return None

    parsed = data.get("parsed")
    if not isinstance(parsed, dict):
        return None

    info = parsed.get("info")
    return info if isinstance(info, dict) else None


def fetch_mint_info(
    rpc_client: httpx.Client,
    mint: str,
) -> dict[str, Any]:
    result = rpc_call(
        rpc_client,
        "getAccountInfo",
        [
            mint,
            {
                "encoding": "jsonParsed",
                "commitment": "confirmed",
            },
        ],
    )
    account = (result or {}).get("value")
    if not account:
        return {
            "exists": False,
            "token_program": None,
            "decimals": None,
            "supply_raw": None,
            "mint_authority": None,
            "freeze_authority": None,
            "parsed": False,
        }

    info = parsed_account_info(account)
    if info is None:
        return {
            "exists": True,
            "token_program": account.get("owner"),
            "decimals": None,
            "supply_raw": None,
            "mint_authority": None,
            "freeze_authority": None,
            "parsed": False,
        }

    return {
        "exists": True,
        "token_program": account.get("owner"),
        "decimals": to_int(info.get("decimals"), 0),
        "supply_raw": str(info.get("supply") or "0"),
        "mint_authority": info.get("mintAuthority"),
        "freeze_authority": info.get("freezeAuthority"),
        "parsed": True,
    }


def fetch_largest_token_accounts(
    rpc_client: httpx.Client,
    mint: str,
) -> list[dict[str, Any]]:
    result = rpc_call(
        rpc_client,
        "getTokenLargestAccounts",
        [
            mint,
            {
                "commitment": "confirmed",
            },
        ],
    )
    value = (result or {}).get("value")
    return value if isinstance(value, list) else []


def fetch_token_account_owners(
    rpc_client: httpx.Client,
    addresses: list[str],
) -> list[dict[str, Any] | None]:
    if not addresses:
        return []

    result = rpc_call(
        rpc_client,
        "getMultipleAccounts",
        [
            addresses,
            {
                "encoding": "jsonParsed",
                "commitment": "confirmed",
            },
        ],
    )
    value = (result or {}).get("value")
    return value if isinstance(value, list) else []


def analyze_concentration(
    rpc_client: httpx.Client,
    mint: str,
    bonding_curve: str,
    supply_raw: str | None,
) -> dict[str, Any]:
    largest = fetch_largest_token_accounts(rpc_client, mint)
    addresses = [
        str(item.get("address"))
        for item in largest
        if item.get("address")
    ]
    accounts = fetch_token_account_owners(
        rpc_client,
        addresses,
    )

    balances_by_owner: dict[str, int] = defaultdict(int)
    curve_balance = 0
    valid_accounts = 0

    for largest_item, account in zip(largest, accounts):
        info = parsed_account_info(account)
        if not info:
            continue

        token_amount = info.get("tokenAmount") or {}
        amount = to_int(
            token_amount.get("amount")
            or largest_item.get("amount"),
            0,
        )
        owner = str(info.get("owner") or "")
        if not owner or amount <= 0:
            continue

        valid_accounts += 1
        if owner == bonding_curve:
            curve_balance += amount
        else:
            balances_by_owner[owner] += amount

    total_supply = max(to_int(supply_raw, 0), 1)

    # V10.1:
    # - la bonding curve / pool est retirée de la liste des holders ;
    # - son solde n'est PAS retiré du dénominateur ;
    # - chaque wallet est mesuré par rapport à la supply totale du token.
    #
    # Exemple : pool 22 %, holder 3,2 % de la supply totale.
    # Le holder reste à 3,2 %, et non 3,2 / 78 = 4,10 %.
    ranked_balances = sorted(
        balances_by_owner.values(),
        reverse=True,
    )

    def percentage_for_top(number: int) -> float:
        return (
            sum(ranked_balances[:number])
            / total_supply
            * 100.0
        )

    return {
        "top1_pct": percentage_for_top(1),
        "top5_pct": percentage_for_top(5),
        "top10_pct": percentage_for_top(10),
        "top20_pct": percentage_for_top(20),
        "distinct_top_owners": len(ranked_balances),
        "curve_balance_pct": (
            curve_balance / max(total_supply, 1) * 100.0
        ),
        "largest_accounts_count": valid_accounts,
    }


def fetch_dex_activity(
    dex_client: httpx.Client,
    mints: list[str],
) -> dict[str, dict[str, Any]]:
    if not mints:
        return {}

    response = dex_client.get(
        f"/tokens/v1/solana/{','.join(mints)}",
        headers={
            "Accept": "application/json",
            "User-Agent": "SOLPULSE-Safety-Engine/7.0",
        },
    )
    response.raise_for_status()
    payload = response.json()

    if not isinstance(payload, list):
        return {}

    candidates: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for pair in payload:
        if not isinstance(pair, dict):
            continue
        base = pair.get("baseToken") or {}
        mint = base.get("address")
        if mint in mints:
            candidates[str(mint)].append(pair)

    activity: dict[str, dict[str, Any]] = {}
    for mint, pairs in candidates.items():
        best = max(
            pairs,
            key=lambda pair: to_float(
                (pair.get("liquidity") or {}).get("usd")
            ),
        )
        m5 = ((best.get("txns") or {}).get("m5") or {})
        activity[mint] = {
            "buys_5m": to_int(m5.get("buys"), 0),
            "sells_5m": to_int(m5.get("sells"), 0),
            "activity_source": "DEX Screener",
        }

    return activity


def choose_targets(
    refresh_seconds: int,
    batch_size: int,
) -> list[sqlite3.Row]:
    with connect_db() as connection:
        rows = connection.execute(
            """
            SELECT
                launches.*,
                safety.assessed_at AS previous_assessed_at
            FROM new_launches launches
            LEFT JOIN safety_assessments safety
                ON safety.mint = launches.mint
            ORDER BY
                CASE WHEN safety.mint IS NULL THEN 0 ELSE 1 END,
                datetime(launches.detected_at) DESC
            LIMIT 300
            """
        ).fetchall()

    targets: list[sqlite3.Row] = []
    current_time = now_utc()

    for row in rows:
        previous = row["previous_assessed_at"]
        if previous:
            try:
                previous_time = datetime.fromisoformat(previous)
                age = (current_time - previous_time).total_seconds()
                if age < refresh_seconds:
                    continue
            except ValueError:
                pass

        targets.append(row)
        if len(targets) >= batch_size:
            break

    return targets


def score_assessment(
    launch: sqlite3.Row,
    mint_info: dict[str, Any],
    concentration: dict[str, Any] | None,
    creator_launch_count: int,
    activity: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    score = 50.0
    reasons: list[str] = []
    warnings: list[str] = []
    hard_reject = False
    complete_analysis = True

    if not mint_info["exists"]:
        hard_reject = True
        score -= 50
        warnings.append("Compte mint introuvable")
        complete_analysis = False
    elif not mint_info["parsed"]:
        score -= 15
        warnings.append(
            "Le compte mint existe mais le RPC ne l'a pas décodé"
        )
        complete_analysis = False
    else:
        mint_authority = mint_info["mint_authority"]
        freeze_authority = mint_info["freeze_authority"]

        if mint_authority is None:
            score += 12
            reasons.append("Mint authority révoquée")
        else:
            score -= 35
            hard_reject = True
            warnings.append("Mint authority encore active")

        if freeze_authority is None:
            score += 12
            reasons.append("Freeze authority révoquée")
        else:
            score -= 35
            hard_reject = True
            warnings.append("Freeze authority encore active")

        if mint_info["token_program"] in {
            TOKEN_PROGRAM,
            TOKEN_2022_PROGRAM,
        }:
            score += 3
            reasons.append("Programme de token reconnu")
        else:
            score -= 8
            warnings.append("Programme de token non reconnu")

    if concentration is None:
        score -= 8
        warnings.append("Concentration des détenteurs indisponible")
        complete_analysis = False
    else:
        top1 = concentration["top1_pct"]
        top10 = concentration["top10_pct"]
        owners = concentration["distinct_top_owners"]

        max_top1 = float(config["safety_max_top1_pct"])
        if top1 > max_top1 + 1e-9:
            score -= 50
            hard_reject = True
            warnings.append(
                f"Un propriétaire contrôle {top1:.2f}% "
                f"de la supply totale "
                f"(maximum {max_top1:.2f}%)"
            )
        elif top1 <= 1.0:
            score += 12
            reasons.append("Plus gros propriétaire ≤ 1 %")
        elif top1 <= 2.0:
            score += 9
            reasons.append("Plus gros propriétaire ≤ 2 %")
        else:
            score += 5
            reasons.append(
                f"Plus gros propriétaire conforme : {top1:.2f}%"
            )

        if top10 <= 40:
            score += 8
            reasons.append("Top 10 correctement réparti")
        elif top10 <= 60:
            score += 2
            reasons.append("Top 10 acceptable")
        elif top10 <= 75:
            score -= 8
            warnings.append("Top 10 concentré")
        elif top10 > float(config["safety_max_top10_pct"]):
            score -= 25
            hard_reject = True
            warnings.append("Concentration Top 10 critique")
        else:
            score -= 15
            warnings.append("Top 10 très concentré")

        if owners >= 10:
            score += 7
            reasons.append("Au moins 10 propriétaires parmi les gros comptes")
        elif owners >= 5:
            score += 3
            reasons.append("Diversité de propriétaires moyenne")
        elif owners < 3:
            score -= 12
            warnings.append("Très peu de propriétaires importants")

    # V10: le nombre de lancements du créateur est conservé
    # pour information, mais n'ajoute ni bonus, ni pénalité, ni rejet.
    reasons.append(
        f"Créateur observé sur {creator_launch_count} lancement(s) "
        f"(informatif uniquement)"
    )

    progress = to_float(launch["progress_pct"], -1)
    if 3 <= progress <= 75:
        score += 5
        reasons.append("Progression de courbe dans une zone observable")
    elif 0 <= progress < 1:
        score -= 4
        warnings.append("Courbe presque inactive")
    elif progress > 95:
        score -= 8
        warnings.append("Courbe proche de la fin")

    buys = to_int(activity.get("buys_5m"), 0)
    sells = to_int(activity.get("sells_5m"), 0)
    activity_source = activity.get(
        "activity_source",
        "Aucune paire DEX",
    )

    if activity_source == "DEX Screener":
        total_trades = buys + sells
        if sells >= 2:
            score += 6
            reasons.append("Ventes réelles observées sur le DEX")
        elif sells == 0 and buys >= 10:
            score -= 10
            warnings.append("Achats sans vente observée")

        if total_trades >= 20:
            score += 4
            reasons.append("Activité récente significative")

        if buys >= 10 and sells > 0 and buys / sells > 10:
            score -= 8
            warnings.append("Ratio achats/ventes extrême")
    else:
        warnings.append(
            "Activité acheteurs/vendeurs non disponible avant paire DEX"
        )

    if launch["uri"]:
        score += 2
        reasons.append("URI de métadonnées présente")
    else:
        score -= 3
        warnings.append("URI de métadonnées absente")

    lifecycle = str(launch["lifecycle_state"] or "DETECTED")
    if lifecycle == "BONDING":
        score += 2
    elif lifecycle in {"NO_ACCOUNT", "DETECTED"}:
        score -= 5
        warnings.append("Bonding curve pas encore confirmée")

    score = max(0.0, min(100.0, score))

    if hard_reject:
        decision = "REJECTED"
    elif (
        complete_analysis
        and score >= float(config["safety_qualified_score"])
    ):
        decision = "QUALIFIED"
    elif score >= float(config["safety_observation_score"]):
        decision = "OBSERVATION"
    else:
        decision = "REJECTED"

    analysis_status = (
        "COMPLETE"
        if complete_analysis
        else "PARTIAL"
    )

    return {
        "score": score,
        "decision": decision,
        "hard_reject": int(hard_reject),
        "reasons": reasons,
        "warnings": warnings,
        "analysis_status": analysis_status,
        "buys_5m": buys,
        "sells_5m": sells,
        "activity_source": activity_source,
    }


def save_assessment(
    launch: sqlite3.Row,
    mint_info: dict[str, Any],
    concentration: dict[str, Any] | None,
    creator_launch_count: int,
    scored: dict[str, Any],
    error_text: str | None = None,
) -> None:
    concentration = concentration or {}

    with connect_db() as connection:
        connection.execute(
            """
            INSERT INTO safety_assessments (
                assessed_at, launch_id, mint, creator,
                symbol, token_name, lifecycle_state, progress_pct,
                safety_score, decision, hard_reject,
                reasons_json, warnings_json,
                mint_account_exists, token_program, decimals,
                supply_raw, mint_authority, freeze_authority,
                mint_authority_revoked, freeze_authority_revoked,
                top1_pct, top5_pct, top10_pct, top20_pct,
                distinct_top_owners, curve_balance_pct,
                largest_accounts_count, creator_launch_count,
                buys_5m, sells_5m, activity_source,
                analysis_status, error_text
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(mint) DO UPDATE SET
                assessed_at = excluded.assessed_at,
                launch_id = excluded.launch_id,
                creator = excluded.creator,
                symbol = excluded.symbol,
                token_name = excluded.token_name,
                lifecycle_state = excluded.lifecycle_state,
                progress_pct = excluded.progress_pct,
                safety_score = excluded.safety_score,
                decision = excluded.decision,
                hard_reject = excluded.hard_reject,
                reasons_json = excluded.reasons_json,
                warnings_json = excluded.warnings_json,
                mint_account_exists = excluded.mint_account_exists,
                token_program = excluded.token_program,
                decimals = excluded.decimals,
                supply_raw = excluded.supply_raw,
                mint_authority = excluded.mint_authority,
                freeze_authority = excluded.freeze_authority,
                mint_authority_revoked = excluded.mint_authority_revoked,
                freeze_authority_revoked = excluded.freeze_authority_revoked,
                top1_pct = excluded.top1_pct,
                top5_pct = excluded.top5_pct,
                top10_pct = excluded.top10_pct,
                top20_pct = excluded.top20_pct,
                distinct_top_owners = excluded.distinct_top_owners,
                curve_balance_pct = excluded.curve_balance_pct,
                largest_accounts_count = excluded.largest_accounts_count,
                creator_launch_count = excluded.creator_launch_count,
                buys_5m = excluded.buys_5m,
                sells_5m = excluded.sells_5m,
                activity_source = excluded.activity_source,
                analysis_status = excluded.analysis_status,
                error_text = excluded.error_text
            """,
            (
                now_iso(),
                launch["id"],
                launch["mint"],
                launch["creator"],
                launch["symbol"],
                launch["name"],
                launch["lifecycle_state"],
                launch["progress_pct"],
                scored["score"],
                scored["decision"],
                scored["hard_reject"],
                json.dumps(
                    scored["reasons"],
                    ensure_ascii=False,
                ),
                json.dumps(
                    scored["warnings"],
                    ensure_ascii=False,
                ),
                int(bool(mint_info.get("exists"))),
                mint_info.get("token_program"),
                mint_info.get("decimals"),
                mint_info.get("supply_raw"),
                mint_info.get("mint_authority"),
                mint_info.get("freeze_authority"),
                int(
                    mint_info.get("exists")
                    and mint_info.get("parsed")
                    and mint_info.get("mint_authority") is None
                ),
                int(
                    mint_info.get("exists")
                    and mint_info.get("parsed")
                    and mint_info.get("freeze_authority") is None
                ),
                concentration.get("top1_pct"),
                concentration.get("top5_pct"),
                concentration.get("top10_pct"),
                concentration.get("top20_pct"),
                concentration.get("distinct_top_owners"),
                concentration.get("curve_balance_pct"),
                concentration.get("largest_accounts_count"),
                creator_launch_count,
                scored["buys_5m"],
                scored["sells_5m"],
                scored["activity_source"],
                scored["analysis_status"],
                error_text,
            ),
        )
        connection.commit()


def count_creator_launches(
    creator: str | None,
) -> int:
    if not creator:
        return 0

    with connect_db() as connection:
        return int(
            connection.execute(
                """
                SELECT COUNT(*)
                FROM new_launches
                WHERE creator = ?
                """,
                (creator,),
            ).fetchone()[0]
        )


def update_engine_state(
    status: str,
    error_text: str = "",
) -> None:
    with connect_db() as connection:
        assessed_count = int(
            connection.execute(
                "SELECT COUNT(*) FROM safety_assessments"
            ).fetchone()[0]
        )
        qualified_count = int(
            connection.execute(
                """
                SELECT COUNT(*)
                FROM safety_assessments
                WHERE decision = 'QUALIFIED'
                """
            ).fetchone()[0]
        )

        write_state(connection, "safety_status", status)
        write_state(connection, "safety_last_scan", now_iso())
        write_state(connection, "safety_last_error", error_text[:500])
        write_state(
            connection,
            "safety_assessed_count",
            str(assessed_count),
        )
        write_state(
            connection,
            "safety_qualified_count",
            str(qualified_count),
        )
        connection.commit()


def run_cycle(
    rpc_client: httpx.Client,
    dex_client: httpx.Client,
    config: dict[str, Any],
) -> int:
    targets = choose_targets(
        refresh_seconds=int(config["safety_refresh_seconds"]),
        batch_size=int(config["safety_batch_size"]),
    )

    if not targets:
        update_engine_state("RUNNING")
        return 0

    dex_activity: dict[str, dict[str, Any]] = {}
    try:
        dex_activity = fetch_dex_activity(
            dex_client,
            [str(row["mint"]) for row in targets],
        )
    except Exception as error:
        print(f"Activité DEX indisponible : {error}")

    completed = 0
    for launch in targets:
        LOCK_PATH.touch(exist_ok=True)
        mint = str(launch["mint"])

        try:
            mint_info = fetch_mint_info(rpc_client, mint)

            concentration = None
            if mint_info["exists"] and mint_info["parsed"]:
                concentration = analyze_concentration(
                    rpc_client=rpc_client,
                    mint=mint,
                    bonding_curve=str(
                        launch["bonding_curve"] or ""
                    ),
                    supply_raw=mint_info["supply_raw"],
                )

            creator_count = count_creator_launches(
                launch["creator"]
            )
            scored = score_assessment(
                launch=launch,
                mint_info=mint_info,
                concentration=concentration,
                creator_launch_count=creator_count,
                activity=dex_activity.get(mint, {}),
                config=config,
            )
            save_assessment(
                launch=launch,
                mint_info=mint_info,
                concentration=concentration,
                creator_launch_count=creator_count,
                scored=scored,
            )
            completed += 1

            print(
                f"{datetime.now().strftime('%H:%M:%S')} | "
                f"{launch['symbol']} | "
                f"{scored['score']:.1f}/100 | "
                f"{scored['decision']}"
            )

        except Exception as error:
            message = str(error)
            print(f"{launch['symbol']} : {message}")

            fallback_mint_info = {
                "exists": False,
                "parsed": False,
                "token_program": None,
                "decimals": None,
                "supply_raw": None,
                "mint_authority": None,
                "freeze_authority": None,
            }
            fallback_score = {
                "score": 0.0,
                "decision": "OBSERVATION",
                "hard_reject": 0,
                "reasons": [],
                "warnings": [
                    "Analyse RPC temporairement indisponible"
                ],
                "analysis_status": "ERROR",
                "buys_5m": 0,
                "sells_5m": 0,
                "activity_source": "Indisponible",
            }
            save_assessment(
                launch=launch,
                mint_info=fallback_mint_info,
                concentration=None,
                creator_launch_count=count_creator_launches(
                    launch["creator"]
                ),
                scored=fallback_score,
                error_text=message[:500],
            )

    update_engine_state("RUNNING")
    return completed


def main() -> None:
    if not DB_PATH.exists():
        print("Base absente. Lance 02_REINITIALISER_1_SOL.bat.")
        return

    config = load_json(CONFIG_PATH)
    if not config.get("safety_engine_enabled", True):
        print("Le Safety Engine est désactivé dans config.json.")
        return

    rpc_url = os.getenv(
        "SOLANA_RPC_URL",
        str(config.get("solana_rpc_url")),
    )
    scan_seconds = float(
        config.get("safety_scan_seconds", 12)
    )

    acquire_lock()
    print("=" * 72)
    print("SOLPULSE V10.1 — SAFETY ENGINE")
    print("=" * 72)
    print(f"RPC : {rpc_url}")
    print("Analyse : autorités, concentration, créateur et activité.")
    print("Décisions : REJECTED, OBSERVATION, QUALIFIED.")
    print("Aucun achat automatique depuis le Safety Engine.")
    print()

    rpc_client = httpx.Client(
        base_url=rpc_url,
        timeout=httpx.Timeout(20.0),
    )
    dex_client = httpx.Client(
        base_url=DEXSCREENER_BASE_URL,
        timeout=httpx.Timeout(15.0),
        follow_redirects=True,
    )

    try:
        update_engine_state("RUNNING")
        while running:
            cycle_start = time.monotonic()
            LOCK_PATH.touch(exist_ok=True)

            try:
                completed = run_cycle(
                    rpc_client,
                    dex_client,
                    config,
                )
                if completed == 0:
                    print(
                        f"{datetime.now().strftime('%H:%M:%S')} | "
                        "Aucune analyse à rafraîchir"
                    )
            except KeyboardInterrupt:
                break
            except Exception as error:
                message = str(error)
                print(f"Erreur Safety Engine : {message}")
                update_engine_state("ERROR", message)

            elapsed = time.monotonic() - cycle_start
            time.sleep(max(1.0, scan_seconds - elapsed))
    finally:
        rpc_client.close()
        dex_client.close()
        update_engine_state("STOPPED")
        release_lock()
        print("Safety Engine arrêté proprement.")


if __name__ == "__main__":
    main()

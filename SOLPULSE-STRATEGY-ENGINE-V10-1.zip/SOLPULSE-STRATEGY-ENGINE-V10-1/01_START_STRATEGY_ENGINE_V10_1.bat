@echo off
title SOLPULSE STRATEGY ENGINE V10.1 - PORT 8518
cd /d "%~dp0"

echo.
echo ============================================================
echo     SOLPULSE STRATEGY ENGINE V10.1 - PORT EXCLUSIF 8518
echo ============================================================
echo.
echo Strategie active :
echo - 1 seule position paper
echo - taille 0.05 SOL
echo - wallet maximum 3.5 %% de la supply estimee
echo - stop initial -20 %%
echo - take profit +100 %%
echo - break-even arme apres +50 %%
echo.
echo Adresse :
echo http://localhost:8518/?version=STRATEGY-ENGINE-V10-1
echo.
echo IMPORTANT :
echo - aucune transaction reelle
echo - aucune cle privee
echo - positions et backtests PAPER uniquement
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Creation de l'environnement Python...
    python -m venv .venv
    if errorlevel 1 (
        echo Python n'est pas installe ou pas reconnu.
        echo Installe Python depuis python.org avec Add Python to PATH.
        pause
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"

echo Installation des dependances...
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
    echo Erreur pendant l'installation.
    pause
    exit /b 1
)

if not exist "data\trading.db" (
    python reset_simulation.py
)

echo Verification et migration de la base...
python migrate_database.py
if errorlevel 1 (
    echo La migration de la base a echoue.
    pause
    exit /b 1
)

if exist "data\prebond_bot.lock" del /q "data\prebond_bot.lock"
if exist "data\new_coin_radar.lock" del /q "data\new_coin_radar.lock"
if exist "data\safety_engine.lock" del /q "data\safety_engine.lock"
if exist "data\qualification_pipeline.lock" del /q "data\qualification_pipeline.lock"
if exist "data\event_recorder.lock" del /q "data\event_recorder.lock"

echo Demarrage du scanner watchlist...
start "SOLPULSE V10.1 - WATCHLIST BOT" cmd /k ""%CD%\.venv\Scripts\python.exe" "%CD%\prebond_paper_bot.py""

echo Demarrage du New Coin Radar...
start "SOLPULSE V10.1 - NEW COIN RADAR" cmd /k ""%CD%\.venv\Scripts\python.exe" "%CD%\new_coin_radar.py""

echo Demarrage du Safety Engine...
start "SOLPULSE V10.1 - SAFETY ENGINE" cmd /k ""%CD%\.venv\Scripts\python.exe" "%CD%\safety_engine.py""

echo Demarrage du Strategy Engine...
start "SOLPULSE V10.1 - STRATEGY ENGINE" cmd /k ""%CD%\.venv\Scripts\python.exe" "%CD%\qualification_pipeline.py""

echo Demarrage de l'Event Recorder...
start "SOLPULSE V10.1 - EVENT RECORDER" cmd /k ""%CD%\.venv\Scripts\python.exe" "%CD%\event_recorder.py""

timeout /t 9 /nobreak >nul

echo Demarrage du dashboard...
start "" "http://localhost:8518/?version=STRATEGY-ENGINE-V10-1"
python -m streamlit run app.py ^
  --server.port 8518 ^
  --server.address localhost ^
  --server.headless true ^
  --browser.gatherUsageStats false

pause

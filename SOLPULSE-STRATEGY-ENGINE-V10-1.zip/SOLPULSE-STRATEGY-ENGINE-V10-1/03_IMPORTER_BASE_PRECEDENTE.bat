@echo off
title SOLPULSE V10.1 - IMPORTER UNE BASE PRECEDENTE
cd /d "%~dp0"

echo.
echo Ferme toutes les fenetres SOLPULSE avant l'import.
echo Une fenetre te demandera de selectionner le fichier trading.db de V9 ou V10 :
echo SOLPULSE-REPLAY-LAB-V9\data\trading.db ou SOLPULSE-STRATEGY-ENGINE-V10\data\trading.db
echo.

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" import_v9_database.py
) else (
    python import_v9_database.py
)

pause

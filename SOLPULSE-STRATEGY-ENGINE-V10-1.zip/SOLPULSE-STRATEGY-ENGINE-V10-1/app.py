
from __future__ import annotations

import json
import math
import sqlite3
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from backtest_engine import default_parameters, run_backtest

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "trading.db"
WATCHLIST_PATH = BASE_DIR / "watchlist.json"
CONFIG_PATH = BASE_DIR / "config.json"

st.set_page_config(
    page_title="SOLPULSE STRATEGY ENGINE V10.1",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    :root {
        --bg:#07090f;--panel:#10141f;--border:rgba(255,255,255,.075);
        --text:#f4f6fb;--muted:#8f98ac;--green:#25e6a5;
        --red:#ff5c78;--purple:#9b7cff;--cyan:#32d7ff;--amber:#ffbf69;
    }
    .stApp {
        background:
          radial-gradient(circle at 82% 2%,rgba(137,105,255,.11),transparent 29rem),
          radial-gradient(circle at 18% 0%,rgba(37,230,165,.055),transparent 25rem),
          var(--bg);
        color:var(--text);
    }
    [data-testid="stHeader"]{background:transparent}
    [data-testid="stSidebar"]{background:#0a0d14;border-right:1px solid var(--border)}
    .block-container{max-width:1700px;padding-top:1.1rem;padding-bottom:3rem}
    .brand{display:flex;align-items:center;gap:.75rem;margin:.15rem 0 .4rem}
    .brand-mark{
        display:grid;place-items:center;width:42px;height:42px;border-radius:13px;
        background:linear-gradient(145deg,var(--green),var(--purple));
        color:#07100e;font-weight:900
    }
    .brand-title{font-size:1.32rem;font-weight:760;letter-spacing:-.04em}
    .brand-subtitle,.muted,.section-note{color:var(--muted);font-size:.78rem}
    .topbar{
        display:flex;justify-content:space-between;align-items:flex-end;
        gap:1rem;margin-bottom:1rem
    }
    .kicker{
        color:var(--green);font-weight:700;font-size:.72rem;
        letter-spacing:.15em;text-transform:uppercase
    }
    .page-title{
        font-size:clamp(1.7rem,4vw,2.7rem);font-weight:780;
        letter-spacing:-.055em;margin:.08rem 0
    }
    .subtitle{color:var(--muted);font-size:.92rem}
    .status-online,.status-offline,.status-warn{
        display:inline-flex;align-items:center;gap:.45rem;padding:.48rem .72rem;
        border-radius:999px;font-size:.78rem;white-space:nowrap
    }
    .status-online{color:var(--green);background:rgba(37,230,165,.08);border:1px solid rgba(37,230,165,.25)}
    .status-offline{color:var(--red);background:rgba(255,92,120,.08);border:1px solid rgba(255,92,120,.25)}
    .status-warn{color:var(--amber);background:rgba(255,191,105,.08);border:1px solid rgba(255,191,105,.25)}
    .dot-online,.dot-offline,.dot-warn{width:7px;height:7px;border-radius:50%}
    .dot-online{background:var(--green);box-shadow:0 0 11px var(--green)}
    .dot-offline{background:var(--red);box-shadow:0 0 11px var(--red)}
    .dot-warn{background:var(--amber);box-shadow:0 0 11px var(--amber)}
    div[data-testid="stMetric"]{
        background:linear-gradient(145deg,rgba(21,26,39,.96),rgba(12,15,24,.96));
        border:1px solid var(--border);border-radius:18px;
        padding:15px 16px;min-height:112px
    }
    div[data-testid="stMetricLabel"]{
        color:var(--muted);font-size:.75rem;text-transform:uppercase;letter-spacing:.08em
    }
    div[data-testid="stMetricValue"]{font-size:1.45rem;font-weight:670;letter-spacing:-.035em}
    .section-head{
        display:flex;justify-content:space-between;align-items:baseline;
        margin:1.2rem 0 .55rem
    }
    .section-title{font-size:1rem;font-weight:650}
    .panel{
        background:linear-gradient(145deg,rgba(21,26,39,.9),rgba(11,14,22,.9));
        border:1px solid var(--border);border-radius:18px;padding:1rem
    }
    .positive{color:var(--green);font-weight:650}
    .negative{color:var(--red);font-weight:650}
    [data-testid="stDataFrame"]{border:1px solid var(--border);border-radius:16px;overflow:hidden}
    .live-note{color:var(--muted);font-size:.76rem;text-align:right;margin-top:.35rem}
    @media(max-width:800px){.topbar{align-items:flex-start;flex-direction:column}}
    </style>
    """,
    unsafe_allow_html=True,
)

PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#9da5b8", family="Inter, system-ui, sans-serif"),
    margin=dict(l=8, r=8, t=38, b=8),
    hoverlabel=dict(
        bgcolor="#171b27",
        font_color="#f4f6fb",
        bordercolor="#2a3040",
    ),
)


def query(sql: str, params: tuple = ()) -> pd.DataFrame:
    if not DB_PATH.exists():
        return pd.DataFrame()
    with sqlite3.connect(DB_PATH, timeout=10) as connection:
        connection.execute("PRAGMA busy_timeout=5000")
        return pd.read_sql_query(sql, connection, params=params)


def load_data():
    return (
        query(
            """
            SELECT
                positions.*,
                risk.peak_pnl_pct,
                risk.break_even_armed,
                risk.active_stop_pct
            FROM positions
            LEFT JOIN position_risk_state risk
                ON risk.position_id = positions.id
            ORDER BY datetime(positions.opened_at) DESC
            """
        ),
        query("SELECT * FROM portfolio_snapshots ORDER BY datetime(timestamp)"),
        query("SELECT * FROM signals ORDER BY datetime(timestamp) DESC LIMIT 500"),
        query("SELECT * FROM paper_orders ORDER BY datetime(timestamp) DESC LIMIT 500"),
        query("SELECT * FROM market_snapshots ORDER BY datetime(timestamp) DESC LIMIT 15000"),
        query("SELECT * FROM bonding_snapshots ORDER BY datetime(timestamp) DESC LIMIT 15000"),
        query("SELECT * FROM new_launches ORDER BY datetime(detected_at) DESC LIMIT 1000"),
        query("SELECT * FROM safety_assessments ORDER BY datetime(assessed_at) DESC LIMIT 1000"),
        query("SELECT * FROM qualification_candidates ORDER BY datetime(updated_at) DESC LIMIT 1000"),
        query("SELECT * FROM qualification_events ORDER BY datetime(timestamp) DESC LIMIT 1000"),
        query("SELECT * FROM bot_state"),
    )


def parse_dates(frame: pd.DataFrame, columns: list[str]) -> None:
    for column in columns:
        if column in frame.columns:
            frame[column] = pd.to_datetime(
                frame[column],
                errors="coerce",
                utc=True,
            )


def latest_per_mint(
    frame: pd.DataFrame,
) -> pd.DataFrame:
    if frame.empty:
        return frame
    return (
        frame.sort_values("timestamp")
        .groupby("token_mint", as_index=False)
        .tail(1)
    )


def state_map(frame: pd.DataFrame) -> dict[str, str]:
    if frame.empty:
        return {}
    return {
        str(row["key"]): str(row["value"])
        for _, row in frame.iterrows()
    }


def fmt_sol(value: float | int | None) -> str:
    number = float(value or 0)
    return f"{number:+.4f} SOL"


def maximum_drawdown(equity: pd.Series) -> float:
    if equity.empty:
        return 0.0
    return float((equity - equity.cummax()).min())


watchlist = json.loads(WATCHLIST_PATH.read_text(encoding="utf-8"))
config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

with st.sidebar:
    st.markdown(
        """
        <div class="brand">
            <div class="brand-mark">S</div>
            <div>
                <div class="brand-title">SOLPULSE</div>
                <div class="brand-subtitle">STRATEGY V10.1 • Holder rule corrected</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.divider()
    page = st.radio(
        "Navigation",
        [
            "Aperçu",
            "Stratégie V10.1",
            "New Coin Radar",
            "Safety Engine",
            "Qualification",
            "Replay & Backtest",
            "Pré-bond",
            "Scanner hybride",
            "Positions",
            "Historique",
            "Signaux",
            "Analytics",
            "Exécution",
            "Watchlist",
        ],
    )
    st.divider()
    st.caption("SOURCES")
    st.success(
        "WebSocket : nouveaux launches\n\n"
        "Solana RPC : bonding curve\n\n"
        "DEX Screener : marché DEX\n\n"
        "Recorder : replay local"
    )
    st.caption("Collecte toutes les 5 s • rendu partiel toutes les 2 s")
    st.divider()
    st.caption("SÉCURITÉ")
    st.info(
        "Lecture on-chain uniquement\n\n"
        "Ordres paper\n\n"
        "Aucune clé privée"
    )


@st.fragment(run_every="2s")
def render_live(selected_page: str) -> None:
    (
        positions,
        portfolio,
        signals,
        orders,
        market,
        bonding,
        launches,
        safety,
        qualifications,
        qualification_events,
        bot_state,
    ) = load_data()

    parse_dates(positions, ["opened_at", "closed_at"])
    parse_dates(portfolio, ["timestamp"])
    parse_dates(signals, ["timestamp"])
    parse_dates(orders, ["timestamp"])
    parse_dates(market, ["timestamp"])
    parse_dates(bonding, ["timestamp"])
    parse_dates(launches, ["detected_at", "last_updated_at"])
    parse_dates(safety, ["assessed_at"])
    parse_dates(
        qualifications,
        [
            "created_at",
            "first_qualified_at",
            "last_sample_at",
            "ready_at",
            "updated_at",
        ],
    )
    parse_dates(qualification_events, ["timestamp"])

    if portfolio.empty:
        st.error("Base vide. Lance 02_REINITIALISER_1_SOL.bat.")
        return

    state = state_map(bot_state)
    status = state.get("status", "STOPPED")
    rpc_status = state.get("rpc_status", "WAITING")
    dex_status = state.get("dex_status", "WAITING")
    error_text = state.get("last_error", "")
    sol_price_usd = float(state.get("sol_price_usd") or 0)

    latest_market = latest_per_mint(market)
    latest_bonding = latest_per_mint(bonding)

    combined = latest_bonding.copy()
    if not latest_market.empty:
        market_columns = [
            "token_mint", "price_sol", "price_usd",
            "change_1m_pct", "change_5m_pct", "change_h1_pct",
            "liquidity_usd", "volume_5m_usd",
            "buys_5m", "sells_5m", "market_cap_usd",
            "score", "data_status", "source_url",
            "pair_address", "dex_id",
        ]
        combined = combined.merge(
            latest_market[market_columns],
            on="token_mint",
            how="outer",
            suffixes=("_curve", "_dex"),
        )

    latest_portfolio = portfolio.iloc[-1]
    closed = positions[positions["status"] == "CLOSED"].copy()
    opened = positions[positions["status"] == "OPEN"].copy()

    equity = float(latest_portfolio["equity_sol"])
    cash = float(latest_portfolio["cash_sol"])
    realized = float(latest_portfolio["realized_pnl_sol"])
    unrealized = float(latest_portfolio["unrealized_pnl_sol"])
    initial_capital = float(portfolio.iloc[0]["equity_sol"])
    total_return = (
        (equity / initial_capital - 1) * 100
        if initial_capital
        else 0
    )

    wins = closed[closed["realized_pnl_sol"] > 0]
    losses = closed[closed["realized_pnl_sol"] < 0]
    win_rate = len(wins) / len(closed) * 100 if len(closed) else 0
    max_dd = maximum_drawdown(portfolio["equity_sol"].astype(float))

    last_tick = "jamais"
    if state.get("last_tick"):
        try:
            tick = pd.to_datetime(state["last_tick"], utc=True)
            seconds = (
                pd.Timestamp.now(tz="UTC") - tick
            ).total_seconds()
            last_tick = f"il y a {max(0, int(seconds))} s"
        except Exception:
            pass

    if status == "RUNNING":
        status_class, dot_class, status_label = (
            "status-online", "dot-online", "SCANNER ON-CHAIN EN LIGNE"
        )
    elif status == "DATA_ERROR":
        status_class, dot_class, status_label = (
            "status-warn", "dot-warn", "SOURCE PARTIELLEMENT INDISPONIBLE"
        )
    else:
        status_class, dot_class, status_label = (
            "status-offline", "dot-offline", "COLLECTEUR ARRÊTÉ"
        )

    st.markdown(
        f"""
        <div class="topbar">
            <div>
                <div class="kicker">Pump program • DEX Screener • Solana</div>
                <div class="page-title">{selected_page}</div>
                <div class="subtitle">
                    Détection des bonding curves et suivi du passage vers PumpSwap.
                </div>
            </div>
            <div>
                <div class="{status_class}">
                    <span class="{dot_class}"></span>{status_label}
                </div>
                <div class="live-note">
                    RPC {rpc_status} • DEX {dex_status} • tick {last_tick}
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if error_text:
        st.warning(f"Dernière erreur : {error_text}")

    m1, m2, m3, m4, m5, m6 = st.columns(6)
    m1.metric("Équité", f"{equity:.4f} SOL", f"{total_return:+.2f} %")
    m2.metric("Cash", f"{cash:.4f} SOL", f"{len(opened)} position(s)")
    m3.metric("PnL réalisé", fmt_sol(realized), "Paper")
    m4.metric("PnL latent", fmt_sol(unrealized), "Paper")
    m5.metric("Win rate", f"{win_rate:.1f} %", f"{len(wins)}W / {len(losses)}L")
    m6.metric("SOL/USD", f"${sol_price_usd:,.2f}" if sol_price_usd else "—")

    if selected_page == "Aperçu":
        left, right = st.columns([1.9, 1])
        with left:
            chart = portfolio[["timestamp", "equity_sol"]].dropna().tail(1200)
            fig = go.Figure(
                go.Scatter(
                    x=chart["timestamp"],
                    y=chart["equity_sol"],
                    mode="lines",
                    line=dict(color="#25e6a5", width=3),
                    fill="tozeroy",
                    fillcolor="rgba(37,230,165,.06)",
                    hovertemplate="%{y:.4f} SOL<extra></extra>",
                )
            )
            fig.add_hline(
                y=initial_capital,
                line_dash="dot",
                line_color="rgba(255,255,255,.25)",
                annotation_text="Capital initial",
            )
            fig.update_layout(
                **PLOTLY_LAYOUT,
                height=365,
                title="Courbe d’équité paper",
                showlegend=False,
                xaxis=dict(showgrid=False),
                yaxis=dict(
                    gridcolor="rgba(255,255,255,.055)",
                    ticksuffix=" SOL",
                ),
            )
            st.plotly_chart(
                fig,
                use_container_width=True,
                config={"displayModeBar": False},
            )

        with right:
            lifecycle_counts = (
                latest_bonding["lifecycle_state"].value_counts()
                if not latest_bonding.empty
                else pd.Series(dtype=int)
            )
            st.markdown('<div class="panel">', unsafe_allow_html=True)
            st.markdown("#### Cycle Pump")
            for lifecycle in [
                "BONDING",
                "GRADUATING",
                "BONDED",
                "DEX_ONLY",
                "UNKNOWN",
            ]:
                st.write(
                    f"**{lifecycle} :** "
                    f"{int(lifecycle_counts.get(lifecycle, 0))}"
                )
            st.write(f"**Drawdown paper :** {max_dd:.4f} SOL")
            st.markdown("</div>", unsafe_allow_html=True)

        st.markdown(
            '<div class="section-head"><div class="section-title">État des cinq contrats</div>'
            '<div class="section-note">Source on-chain prioritaire</div></div>',
            unsafe_allow_html=True,
        )
        if combined.empty:
            st.info("En attente du premier appel RPC.")
        else:
            st.dataframe(
                combined[
                    [
                        "symbol", "lifecycle_state",
                        "progress_pct", "curve_price_usd",
                        "real_quote_reserves_sol",
                        "complete", "rpc_status",
                        "data_status",
                    ]
                ],
                use_container_width=True,
                hide_index=True,
                column_config={
                    "symbol": "Token",
                    "lifecycle_state": "État",
                    "progress_pct": st.column_config.ProgressColumn(
                        "Progression",
                        min_value=0,
                        max_value=100,
                        format="%.1f %%",
                    ),
                    "curve_price_usd": st.column_config.NumberColumn(
                        "Prix courbe",
                        format="$ %.10f",
                    ),
                    "real_quote_reserves_sol": st.column_config.NumberColumn(
                        "SOL courbe",
                        format="%.3f SOL",
                    ),
                    "complete": "Complete",
                    "rpc_status": "RPC",
                    "data_status": "DEX",
                },
            )



    elif selected_page == "Stratégie V10.1":
        st.markdown(
            '<div class="section-head"><div class="section-title">'
            'Règles actives du robot paper</div>'
            '<div class="section-note">'
            'Version V10.1 — pourcentage sur supply totale</div></div>',
            unsafe_allow_html=True,
        )

        st.warning(
            "Ces règles commandent uniquement des positions fictives. "
            "Aucun wallet et aucune transaction réelle ne sont utilisés."
        )

        left, right = st.columns(2)

        with left:
            st.markdown('<div class="panel">', unsafe_allow_html=True)
            st.markdown("### Qualification renforcée")
            st.write("**Holder maximum :** 3,5 % de la supply totale — pool ignorée")
            st.write("**Launches du créateur :** informatifs, sans pénalité")
            st.write("**Safety minimum :** 72 / 100")
            st.write("**Qualification minimum :** 78 / 100")
            st.write("**Échantillons :** 8 minimum")
            st.write("**Stabilité :** 80 % des échantillons minimum")
            st.write("**Bonding :** entre 5 % et 80 %")
            st.write("**Progression :** au moins +1 point")
            st.write("**Variation de prix :** maximum ±20 %")
            st.write("**Fraîcheur Safety :** moins de 180 secondes")
            st.markdown("</div>", unsafe_allow_html=True)

        with right:
            st.markdown('<div class="panel">', unsafe_allow_html=True)
            st.markdown("### Position et sorties")
            st.write("**Taille :** 0,05 SOL paper")
            st.write("**Positions simultanées :** 1 maximum")
            st.write("**Exposition maximale :** 0,05 SOL")
            st.write("**Stop initial :** −20 %")
            st.write("**Take-profit :** +100 %")
            st.write("**Break-even armé à :** +50 %")
            st.write("**Stop après armement :** +1 % net simulé")
            st.write("**Durée maximale :** 20 minutes")
            st.write("**Frais de courbe simulés :** 1,25 % par côté")
            st.write("**Frais réseau simulés :** 0,000005 SOL, sans priorité")
            st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("### Observation adaptative")
        st.info(
            "Le délai normal est de 120 secondes. Il descend à 60 secondes "
            "seulement lorsque la progression atteint au moins +3 points, "
            "que le prix reste entre 0 % et +15 %, que huit échantillons "
            "sont présents et qu’au moins 85 % sont stables."
        )

        if opened.empty:
            st.caption("Aucune position paper ouverte actuellement.")
        else:
            risk_view = opened[
                [
                    "symbol",
                    "opened_at",
                    "entry_sol",
                    "peak_pnl_pct",
                    "break_even_armed",
                    "active_stop_pct",
                    "current_value_sol",
                ]
            ]
            st.markdown("### Risque de la position actuelle")
            st.dataframe(
                risk_view,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "symbol": "Token",
                    "opened_at": st.column_config.DatetimeColumn(
                        "Ouverture",
                        format="DD/MM HH:mm:ss",
                    ),
                    "entry_sol": st.column_config.NumberColumn(
                        "Entrée",
                        format="%.4f SOL",
                    ),
                    "peak_pnl_pct": st.column_config.NumberColumn(
                        "Pic PnL",
                        format="%+.2f %%",
                    ),
                    "break_even_armed": st.column_config.CheckboxColumn(
                        "Break-even armé"
                    ),
                    "active_stop_pct": st.column_config.NumberColumn(
                        "Stop actif",
                        format="%+.2f %%",
                    ),
                    "current_value_sol": st.column_config.NumberColumn(
                        "Valeur",
                        format="%.4f SOL",
                    ),
                },
            )

    elif selected_page == "New Coin Radar":
        radar_status = state.get("radar_status", "STOPPED")
        radar_error = state.get("radar_last_error", "")

        st.markdown(
            '<div class="section-head"><div class="section-title">'
            'Nouveaux lancements Pump détectés</div>'
            '<div class="section-note">'
            'CreateEvent en direct — aucun achat automatique</div></div>',
            unsafe_allow_html=True,
        )

        if radar_status == "RUNNING":
            st.success("New Coin Radar connecté au flux WebSocket.")
        elif radar_status == "RECONNECTING":
            st.warning(
                "Le radar tente de se reconnecter au WebSocket Solana."
            )
        else:
            st.error(
                "Le radar n’est pas connecté. Vérifie la fenêtre "
                "SOLPULSE V10.1 — NEW COIN RADAR."
            )

        if radar_error:
            st.caption(f"Dernière erreur radar : {radar_error}")

        if launches.empty:
            st.info(
                "Aucun CreateEvent enregistré pour le moment. "
                "Laisse le radar fonctionner quelques instants."
            )
        else:
            radar = launches.copy()

            if not safety.empty:
                safety_columns = [
                    "mint", "safety_score", "decision",
                    "hard_reject", "analysis_status",
                    "top1_pct", "top10_pct",
                    "creator_launch_count",
                    "mint_authority_revoked",
                    "freeze_authority_revoked",
                ]
                radar = radar.merge(
                    safety[safety_columns],
                    on="mint",
                    how="left",
                )
            else:
                radar["safety_score"] = pd.NA
                radar["decision"] = "PENDING"
                radar["hard_reject"] = 0
                radar["analysis_status"] = "PENDING"
                radar["top1_pct"] = pd.NA
                radar["top10_pct"] = pd.NA
                radar["creator_launch_count"] = pd.NA
                radar["mint_authority_revoked"] = pd.NA
                radar["freeze_authority_revoked"] = pd.NA

            radar["decision"] = radar["decision"].fillna("PENDING")

            if not qualifications.empty:
                pipeline_columns = [
                    "mint",
                    "state",
                    "qualification_score",
                    "observation_samples",
                    "progress_delta_pct",
                    "position_id",
                ]
                radar = radar.merge(
                    qualifications[pipeline_columns],
                    on="mint",
                    how="left",
                )
            else:
                radar["state"] = "PENDING"
                radar["qualification_score"] = pd.NA
                radar["observation_samples"] = pd.NA
                radar["progress_delta_pct"] = pd.NA
                radar["position_id"] = pd.NA

            radar["state"] = radar["state"].fillna("PENDING")
            current_time = pd.Timestamp.now(tz="UTC")
            radar["age_seconds"] = (
                current_time - radar["detected_at"]
            ).dt.total_seconds().clip(lower=0)

            last_5m = int((radar["age_seconds"] <= 300).sum())
            last_hour = int((radar["age_seconds"] <= 3600).sum())
            bonding_count = int(
                (radar["lifecycle_state"] == "BONDING").sum()
            )
            complete_count = int(
                (radar["lifecycle_state"] == "CURVE_COMPLETE").sum()
            )
            watchlist_count = int(
                (radar["is_in_watchlist"] == 1).sum()
            )

            a, b, c, d, e, f = st.columns(6)
            a.metric("Détectés", len(radar))
            b.metric("5 dernières min", last_5m)
            c.metric("Dernière heure", last_hour)
            d.metric("Bonding actif", bonding_count)
            e.metric("Courbes terminées", complete_count)
            f.metric("Dans watchlist", watchlist_count)

            radar["launches_creator"] = (
                radar.groupby("creator")["mint"]
                .transform("count")
                .fillna(0)
            )
            radar["âge"] = radar["age_seconds"].apply(
                lambda seconds: (
                    f"{int(seconds)} s"
                    if seconds < 60
                    else f"{int(seconds // 60)} min"
                    if seconds < 3600
                    else f"{seconds / 3600:.1f} h"
                )
            )
            radar["solscan"] = (
                "https://solscan.io/tx/"
                + radar["signature"].astype(str)
            )

            table = radar[
                [
                    "detected_at",
                    "âge",
                    "symbol",
                    "name",
                    "mint",
                    "lifecycle_state",
                    "progress_pct",
                    "curve_price_usd",
                    "real_quote_reserves_sol",
                    "safety_score",
                    "decision",
                    "qualification_score",
                    "state",
                    "launches_creator",
                    "is_in_watchlist",
                    "rpc_status",
                    "solscan",
                ]
            ].head(250)

            st.dataframe(
                table,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "detected_at": st.column_config.DatetimeColumn(
                        "Détection",
                        format="DD/MM HH:mm:ss",
                    ),
                    "âge": "Âge",
                    "symbol": "Ticker",
                    "name": "Nom",
                    "mint": st.column_config.TextColumn(
                        "Mint",
                        width="large",
                    ),
                    "lifecycle_state": "Cycle",
                    "progress_pct": st.column_config.ProgressColumn(
                        "Bonding",
                        min_value=0,
                        max_value=100,
                        format="%.2f %%",
                    ),
                    "curve_price_usd": st.column_config.NumberColumn(
                        "Prix courbe",
                        format="$ %.10f",
                    ),
                    "real_quote_reserves_sol": st.column_config.NumberColumn(
                        "SOL courbe",
                        format="%.4f",
                    ),
                    "safety_score": st.column_config.ProgressColumn(
                        "Safety",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "decision": "Safety",
                    "qualification_score": st.column_config.ProgressColumn(
                        "Qualification",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "state": "Pipeline",
                    "launches_creator": "Launches créateur",
                    "is_in_watchlist": st.column_config.CheckboxColumn(
                        "Watchlist"
                    ),
                    "rpc_status": "RPC",
                    "solscan": st.column_config.LinkColumn(
                        "Transaction",
                        display_text="Solscan",
                    ),
                },
            )

            selected_mint = st.selectbox(
                "Inspecter un lancement",
                radar["mint"].head(250).tolist(),
                format_func=lambda mint: (
                    f"{radar.loc[radar['mint'] == mint, 'symbol'].iloc[0]}"
                    f" — {mint[:8]}…{mint[-6:]}"
                ),
                key="radar_launch_selector",
            )
            selected = radar[
                radar["mint"] == selected_mint
            ].iloc[0]

            left, right = st.columns([1.25, 1])
            with left:
                st.markdown('<div class="panel">', unsafe_allow_html=True)
                st.markdown(
                    f"### {selected['symbol']} — {selected['name']}"
                )
                st.code(selected["mint"])
                st.write(f"**Créateur :** `{selected['creator']}`")
                st.write(
                    f"**Bonding curve :** "
                    f"`{selected['bonding_curve']}`"
                )
                st.write(
                    f"**Cycle :** {selected['lifecycle_state']}"
                )
                progress_value = selected["progress_pct"]
                progress_text = (
                    f"{float(progress_value):.2f} %"
                    if pd.notna(progress_value)
                    else "en attente"
                )
                st.write(f"**Progression :** {progress_text}")
                safety_value = selected.get("safety_score")
                safety_text = (
                    f"{float(safety_value):.1f} / 100"
                    if pd.notna(safety_value)
                    else "en attente"
                )
                st.write(f"**Safety score :** {safety_text}")
                st.write(
                    f"**Décision :** {selected.get('decision', 'PENDING')}"
                )
                st.markdown("</div>", unsafe_allow_html=True)

            with right:
                st.markdown('<div class="panel">', unsafe_allow_html=True)
                st.markdown("### Contrôles de prudence")
                creator_launches = int(
                    selected["launches_creator"] or 0
                )
                st.write(
                    f"**Launches observés pour ce créateur :** "
                    f"{creator_launches}"
                )
                st.write(
                    "**Achat automatique :** désactivé pour le radar"
                )
                st.write(
                    "**Métadonnées externes :** non téléchargées "
                    "automatiquement"
                )
                st.write(
                    "**Analyse recommandée :** attendre l’activité, "
                    "les acheteurs et la progression de courbe"
                )
                st.markdown("</div>", unsafe_allow_html=True)

            metadata_uri = str(selected.get("uri") or "")
            if metadata_uri:
                st.caption(f"URI déclarée on-chain : {metadata_uri}")


    elif selected_page == "Safety Engine":
        safety_status = state.get("safety_status", "STOPPED")
        safety_error = state.get("safety_last_error", "")
        safety_last_scan = state.get("safety_last_scan", "")

        st.markdown(
            '<div class="section-head"><div class="section-title">'
            'Qualification des nouveaux lancements</div>'
            '<div class="section-note">'
            'Autorités, concentration, créateur et activité</div></div>',
            unsafe_allow_html=True,
        )

        if safety_status == "RUNNING":
            st.success(
                "Safety Engine en ligne. "
                "Il analyse quelques tokens à la fois pour ménager le RPC."
            )
        elif safety_status == "ERROR":
            st.warning("Le Safety Engine rencontre une erreur RPC temporaire.")
        else:
            st.error(
                "Le Safety Engine est arrêté. Vérifie sa fenêtre noire."
            )

        if safety_last_scan:
            st.caption(f"Dernier cycle : {safety_last_scan}")
        if safety_error:
            st.caption(f"Dernière erreur : {safety_error}")

        if safety.empty:
            st.info(
                "Aucune évaluation enregistrée. "
                "Le moteur commence par les lancements les plus récents."
            )
        else:
            qualified = safety[safety["decision"] == "QUALIFIED"]
            observation = safety[safety["decision"] == "OBSERVATION"]
            rejected = safety[safety["decision"] == "REJECTED"]
            hard_rejected = safety[safety["hard_reject"] == 1]
            complete = safety[safety["analysis_status"] == "COMPLETE"]

            a, b, c, d, e = st.columns(5)
            a.metric("Évalués", len(safety))
            b.metric("Qualifiés", len(qualified))
            c.metric("Observation", len(observation))
            d.metric("Rejetés", len(rejected))
            e.metric("Analyses complètes", len(complete))

            safety_view = safety.copy()

            def decode_list(raw: str | None) -> str:
                try:
                    values = json.loads(raw) if raw else []
                    return " • ".join(str(value) for value in values)
                except Exception:
                    return str(raw or "")

            safety_view["raisons"] = safety_view[
                "reasons_json"
            ].apply(decode_list)
            safety_view["alertes"] = safety_view[
                "warnings_json"
            ].apply(decode_list)

            st.dataframe(
                safety_view[
                    [
                        "assessed_at",
                        "symbol",
                        "token_name",
                        "safety_score",
                        "decision",
                        "hard_reject",
                        "mint_authority_revoked",
                        "freeze_authority_revoked",
                        "top1_pct",
                        "top10_pct",
                        "distinct_top_owners",
                        "creator_launch_count",
                        "buys_5m",
                        "sells_5m",
                        "analysis_status",
                    ]
                ].sort_values(
                    ["decision", "safety_score"],
                    ascending=[True, False],
                ),
                use_container_width=True,
                hide_index=True,
                column_config={
                    "assessed_at": st.column_config.DatetimeColumn(
                        "Analyse",
                        format="DD/MM HH:mm:ss",
                    ),
                    "symbol": "Ticker",
                    "token_name": "Nom",
                    "safety_score": st.column_config.ProgressColumn(
                        "Safety score",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "decision": "Décision",
                    "hard_reject": st.column_config.CheckboxColumn(
                        "Blocage dur"
                    ),
                    "mint_authority_revoked": st.column_config.CheckboxColumn(
                        "Mint révoqué"
                    ),
                    "freeze_authority_revoked": st.column_config.CheckboxColumn(
                        "Freeze révoqué"
                    ),
                    "top1_pct": st.column_config.NumberColumn(
                        "Top 1",
                        format="%.2f %%",
                    ),
                    "top10_pct": st.column_config.NumberColumn(
                        "Top 10",
                        format="%.2f %%",
                    ),
                    "distinct_top_owners": "Owners top comptes",
                    "creator_launch_count": "Launches créateur (info)",
                    "buys_5m": "Achats 5 min",
                    "sells_5m": "Ventes 5 min",
                    "analysis_status": "État analyse",
                },
            )

            selectable = safety_view.sort_values(
                "assessed_at",
                ascending=False,
            )
            selected_mint = st.selectbox(
                "Inspecter une évaluation",
                selectable["mint"].tolist(),
                format_func=lambda mint: (
                    f"{selectable.loc[selectable['mint'] == mint, 'symbol'].iloc[0]}"
                    f" — {mint[:8]}…{mint[-6:]}"
                ),
                key="safety_selector",
            )
            selected = selectable[
                selectable["mint"] == selected_mint
            ].iloc[0]

            score_value = float(selected["safety_score"] or 0)
            gauge = go.Figure(
                go.Indicator(
                    mode="gauge+number",
                    value=score_value,
                    number={"suffix": " / 100"},
                    title={"text": str(selected["decision"])},
                    gauge={
                        "axis": {"range": [0, 100]},
                        "bar": {"color": "#25e6a5"},
                        "steps": [
                            {"range": [0, 45], "color": "rgba(255,92,120,.18)"},
                            {"range": [45, 72], "color": "rgba(255,191,105,.18)"},
                            {"range": [72, 100], "color": "rgba(37,230,165,.14)"},
                        ],
                    },
                )
            )
            gauge.update_layout(
                **PLOTLY_LAYOUT,
                height=300,
            )

            left, right = st.columns([1, 1.4])
            with left:
                st.plotly_chart(
                    gauge,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

            with right:
                st.markdown('<div class="panel">', unsafe_allow_html=True)
                st.markdown(
                    f"### {selected['symbol']} — {selected['token_name']}"
                )
                st.code(selected["mint"])
                st.write(
                    f"**Mint authority :** "
                    f"{'révoquée' if pd.notna(selected['mint_authority_revoked']) and int(selected['mint_authority_revoked']) == 1 else selected['mint_authority'] or 'inconnue'}"
                )
                st.write(
                    f"**Freeze authority :** "
                    f"{'révoquée' if pd.notna(selected['freeze_authority_revoked']) and int(selected['freeze_authority_revoked']) == 1 else selected['freeze_authority'] or 'inconnue'}"
                )
                st.write(
                    f"**Top 1 / Top 10 :** "
                    f"{float(selected['top1_pct'] or 0):.2f} % / "
                    f"{float(selected['top10_pct'] or 0):.2f} %"
                )
                st.write(
                    f"**Créateur :** "
                    f"{int(selected['creator_launch_count'] or 0)} "
                    f"lancement(s) observé(s)"
                )
                st.write(
                    f"**Activité DEX 5 min :** "
                    f"{int(selected['buys_5m'] or 0)} achats / "
                    f"{int(selected['sells_5m'] or 0)} ventes"
                )
                st.markdown("</div>", unsafe_allow_html=True)

            reason_col, warning_col = st.columns(2)
            with reason_col:
                st.markdown("#### Points positifs")
                if selected["raisons"]:
                    st.success(selected["raisons"])
                else:
                    st.info("Aucun point positif confirmé.")

            with warning_col:
                st.markdown("#### Alertes")
                if selected["alertes"]:
                    st.warning(selected["alertes"])
                else:
                    st.success("Aucune alerte enregistrée.")

            st.caption(
                "QUALIFIED signifie seulement que les contrôles V7 ont été "
                "passés. Cela ne constitue ni une garantie de sécurité ni "
                "une instruction d’achat."
            )


    elif selected_page == "Qualification":
        pipeline_status = state.get(
            "qualification_status",
            "STOPPED",
        )
        pipeline_error = state.get(
            "qualification_last_error",
            "",
        )
        pipeline_cycle = state.get(
            "qualification_last_cycle",
            "",
        )

        st.markdown(
            '<div class="section-head"><div class="section-title">'
            'Pipeline de qualification automatique</div>'
            '<div class="section-note">'
            'Observation → Ready → Position paper → Closed</div></div>',
            unsafe_allow_html=True,
        )

        if pipeline_status == "RUNNING":
            st.success(
                "Qualification Pipeline en ligne. "
                "Seules des positions paper peuvent être ouvertes."
            )
        elif pipeline_status == "ERROR":
            st.warning(
                "Le pipeline rencontre une erreur RPC temporaire."
            )
        else:
            st.error(
                "Le pipeline est arrêté. Vérifie la fenêtre "
                "SOLPULSE V10.1 — STRATEGY ENGINE."
            )

        if pipeline_cycle:
            st.caption(f"Dernier cycle : {pipeline_cycle}")
        if pipeline_error:
            st.caption(f"Dernière erreur : {pipeline_error}")

        if qualifications.empty:
            st.info(
                "Aucun candidat pour le moment. "
                "Un token doit d'abord être QUALIFIED par le Safety Engine."
            )
        else:
            pipeline = qualifications.copy()
            current_time = pd.Timestamp.now(tz="UTC")
            observation_seconds = float(
                config.get(
                    "qualification_observation_seconds",
                    90,
                )
            )

            pipeline["observation_age_seconds"] = (
                current_time - pipeline["first_qualified_at"]
            ).dt.total_seconds()
            pipeline["observation_age_seconds"] = (
                pipeline["observation_age_seconds"]
                .fillna(0)
                .clip(lower=0)
            )
            pipeline["remaining_seconds"] = (
                observation_seconds
                - pipeline["observation_age_seconds"]
            ).clip(lower=0)
            pipeline["observation"] = pipeline.apply(
                lambda row: (
                    f"{int(row['remaining_seconds'])} s restantes"
                    if row["state"] == "OBSERVATION"
                    else "terminée"
                    if row["state"] in {
                        "READY",
                        "PAPER_POSITION",
                        "CLOSED",
                    }
                    else "en pause"
                ),
                axis=1,
            )

            observation = pipeline[
                pipeline["state"] == "OBSERVATION"
            ]
            ready = pipeline[pipeline["state"] == "READY"]
            paper = pipeline[
                pipeline["state"] == "PAPER_POSITION"
            ]
            rejected = pipeline[
                pipeline["state"] == "REJECTED"
            ]
            closed_candidates = pipeline[
                pipeline["state"] == "CLOSED"
            ]

            a, b, c, d, e, f = st.columns(6)
            a.metric("Candidats", len(pipeline))
            b.metric("Observation", len(observation))
            c.metric("Ready", len(ready))
            d.metric("Positions paper", len(paper))
            e.metric("Clôturés", len(closed_candidates))
            f.metric("Rejetés", len(rejected))

            state_order = {
                "PAPER_POSITION": 0,
                "READY": 1,
                "OBSERVATION": 2,
                "PAUSED": 3,
                "CLOSED": 4,
                "EXPIRED": 5,
                "REJECTED": 6,
            }
            pipeline["state_order"] = (
                pipeline["state"]
                .map(state_order)
                .fillna(99)
            )
            pipeline = pipeline.sort_values(
                ["state_order", "qualification_score"],
                ascending=[True, False],
            )

            st.dataframe(
                pipeline[
                    [
                        "symbol",
                        "token_name",
                        "state",
                        "safety_score",
                        "qualification_score",
                        "observation",
                        "observation_samples",
                        "stable_samples",
                        "current_progress_pct",
                        "progress_delta_pct",
                        "price_change_pct",
                        "creator_launch_count",
                        "reason",
                    ]
                ],
                use_container_width=True,
                hide_index=True,
                column_config={
                    "symbol": "Ticker",
                    "token_name": "Nom",
                    "state": "État",
                    "safety_score": st.column_config.ProgressColumn(
                        "Safety",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "qualification_score": st.column_config.ProgressColumn(
                        "Qualification",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "observation": "Temporisation",
                    "observation_samples": "Échantillons",
                    "stable_samples": "Échantillons stables",
                    "current_progress_pct": st.column_config.NumberColumn(
                        "Bonding",
                        format="%.2f %%",
                    ),
                    "progress_delta_pct": st.column_config.NumberColumn(
                        "Progression Δ",
                        format="%+.2f %%",
                    ),
                    "price_change_pct": st.column_config.NumberColumn(
                        "Prix Δ",
                        format="%+.2f %%",
                    ),
                    "creator_launch_count": "Launches créateur (info)",
                    "reason": st.column_config.TextColumn(
                        "Explication",
                        width="large",
                    ),
                },
            )

            selectable = pipeline[
                pipeline["mint"].notna()
            ]
            selected_mint = st.selectbox(
                "Inspecter un candidat",
                selectable["mint"].tolist(),
                format_func=lambda mint: (
                    f"{selectable.loc[selectable['mint'] == mint, 'symbol'].iloc[0]}"
                    f" — {mint[:8]}…{mint[-6:]}"
                ),
                key="qualification_selector",
            )
            selected = selectable[
                selectable["mint"] == selected_mint
            ].iloc[0]

            left, right = st.columns([1, 1.35])

            with left:
                gauge_value = float(
                    selected["qualification_score"] or 0
                )
                gauge = go.Figure(
                    go.Indicator(
                        mode="gauge+number",
                        value=gauge_value,
                        number={"suffix": " / 100"},
                        title={"text": str(selected["state"])},
                        gauge={
                            "axis": {"range": [0, 100]},
                            "bar": {"color": "#9b7cff"},
                            "steps": [
                                {
                                    "range": [0, 60],
                                    "color": "rgba(255,92,120,.16)",
                                },
                                {
                                    "range": [60, 75],
                                    "color": "rgba(255,191,105,.17)",
                                },
                                {
                                    "range": [75, 100],
                                    "color": "rgba(37,230,165,.14)",
                                },
                            ],
                        },
                    )
                )
                gauge.update_layout(
                    **PLOTLY_LAYOUT,
                    height=300,
                )
                st.plotly_chart(
                    gauge,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

            with right:
                st.markdown(
                    '<div class="panel">',
                    unsafe_allow_html=True,
                )
                st.markdown(
                    f"### {selected['symbol']} — "
                    f"{selected['token_name']}"
                )
                st.code(selected["mint"])
                st.write(
                    f"**État :** {selected['state']}"
                )
                st.write(
                    f"**Safety / Qualification :** "
                    f"{float(selected['safety_score'] or 0):.1f} / "
                    f"{float(selected['qualification_score'] or 0):.1f}"
                )
                st.write(
                    f"**Échantillons :** "
                    f"{int(selected['observation_samples'] or 0)} "
                    f"dont {int(selected['stable_samples'] or 0)} stables"
                )
                st.write(
                    f"**Progression de courbe :** "
                    f"{float(selected['current_progress_pct'] or 0):.2f} % "
                    f"({float(selected['progress_delta_pct'] or 0):+.2f} %)"
                )
                st.write(
                    f"**Variation de prix observée :** "
                    f"{float(selected['price_change_pct'] or 0):+.2f} %"
                )
                st.write(
                    f"**Position liée :** "
                    f"{int(selected['position_id']) if pd.notna(selected['position_id']) else 'aucune'}"
                )
                st.markdown(
                    "</div>",
                    unsafe_allow_html=True,
                )

            st.markdown("#### Journal des transitions")
            if qualification_events.empty:
                st.info("Aucune transition enregistrée.")
            else:
                token_events = qualification_events[
                    qualification_events["mint"] == selected_mint
                ].head(50)
                st.dataframe(
                    token_events[
                        [
                            "timestamp",
                            "previous_state",
                            "new_state",
                            "qualification_score",
                            "reason",
                        ]
                    ],
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "timestamp": st.column_config.DatetimeColumn(
                            "Heure",
                            format="DD/MM HH:mm:ss",
                        ),
                        "previous_state": "Avant",
                        "new_state": "Après",
                        "qualification_score": st.column_config.NumberColumn(
                            "Score",
                            format="%.1f",
                        ),
                        "reason": st.column_config.TextColumn(
                            "Raison",
                            width="large",
                        ),
                    },
                )

            st.caption(
                "Une position paper est ouverte seulement après une analyse "
                "Safety complète, 90 secondes d'observation, plusieurs "
                "échantillons stables et une bonding curve encore active."
            )


    elif selected_page == "Replay & Backtest":
        recorder_status = state.get(
            "recorder_status",
            "STOPPED",
        )
        recorder_error = state.get(
            "recorder_last_error",
            "",
        )
        recorder_last_sample = state.get(
            "recorder_last_sample",
            "",
        )
        sample_count_state = int(
            state.get("recorder_sample_count") or 0
        )
        event_count_state = int(
            state.get("recorder_event_count") or 0
        )

        st.markdown(
            '<div class="section-head"><div class="section-title">'
            'Replay événementiel et laboratoire de backtest</div>'
            '<div class="section-note">'
            'Données enregistrées localement toutes les cinq secondes</div></div>',
            unsafe_allow_html=True,
        )

        if recorder_status == "RUNNING":
            st.success(
                "Event Recorder en ligne. "
                "Les observations sont conservées dans SQLite."
            )
        elif recorder_status == "ERROR":
            st.warning(
                "L’Event Recorder rencontre une erreur temporaire."
            )
        else:
            st.error(
                "L’Event Recorder est arrêté. Vérifie sa fenêtre noire."
            )

        if recorder_last_sample:
            st.caption(
                f"Dernier échantillon : {recorder_last_sample}"
            )
        if recorder_error:
            st.caption(f"Dernière erreur : {recorder_error}")

        runs_count = query(
            "SELECT COUNT(*) AS count FROM backtest_runs"
        )
        trades_count = query(
            "SELECT COUNT(*) AS count FROM backtest_trades"
        )
        recorded_tokens = query(
            "SELECT COUNT(DISTINCT mint) AS count FROM research_samples"
        )

        a, b, c, d, e = st.columns(5)
        a.metric("Échantillons", sample_count_state)
        b.metric("Événements", event_count_state)
        c.metric(
            "Tokens enregistrés",
            int(recorded_tokens.iloc[0]["count"])
            if not recorded_tokens.empty
            else 0,
        )
        d.metric(
            "Backtests",
            int(runs_count.iloc[0]["count"])
            if not runs_count.empty
            else 0,
        )
        e.metric(
            "Trades simulés",
            int(trades_count.iloc[0]["count"])
            if not trades_count.empty
            else 0,
        )

        token_summary = query(
            """
            SELECT
                mint,
                MAX(symbol) AS symbol,
                MAX(token_name) AS token_name,
                COUNT(*) AS samples,
                MIN(timestamp) AS first_sample,
                MAX(timestamp) AS last_sample,
                MAX(progress_pct) AS max_progress_pct,
                MAX(safety_score) AS max_safety_score,
                MAX(qualification_score) AS max_qualification_score
            FROM research_samples
            GROUP BY mint
            ORDER BY datetime(last_sample) DESC
            LIMIT 500
            """
        )

        if token_summary.empty:
            st.info(
                "Le recorder n’a pas encore accumulé de données. "
                "Laisse V10.1 fonctionner quelques minutes."
            )
        else:
            parse_dates(
                token_summary,
                ["first_sample", "last_sample"],
            )

            st.markdown("### Rejouer un token")
            selected_mint = st.selectbox(
                "Token enregistré",
                token_summary["mint"].tolist(),
                format_func=lambda mint: (
                    f"{token_summary.loc[token_summary['mint'] == mint, 'symbol'].iloc[0]}"
                    f" — {mint[:8]}…{mint[-6:]}"
                ),
                key="replay_token_selector",
            )

            samples = query(
                """
                SELECT *
                FROM research_samples
                WHERE mint = ?
                ORDER BY datetime(timestamp), id
                LIMIT 10000
                """,
                (selected_mint,),
            )
            events = query(
                """
                SELECT *
                FROM research_events
                WHERE mint = ?
                ORDER BY datetime(timestamp) DESC, id DESC
                LIMIT 500
                """,
                (selected_mint,),
            )
            parse_dates(samples, ["timestamp", "detected_at"])
            parse_dates(events, ["timestamp"])

            if not samples.empty:
                selected_symbol = str(
                    samples.iloc[-1]["symbol"] or ""
                )
                first_time = samples.iloc[0]["timestamp"]
                last_time = samples.iloc[-1]["timestamp"]
                duration_seconds = (
                    last_time - first_time
                ).total_seconds()

                r1, r2, r3, r4 = st.columns(4)
                r1.metric("Échantillons token", len(samples))
                r2.metric(
                    "Durée enregistrée",
                    (
                        f"{duration_seconds / 60:.1f} min"
                        if duration_seconds < 3600
                        else f"{duration_seconds / 3600:.1f} h"
                    ),
                )
                r3.metric(
                    "Progression max",
                    f"{samples['progress_pct'].max():.2f} %"
                    if samples["progress_pct"].notna().any()
                    else "—",
                )
                r4.metric(
                    "Safety max",
                    f"{samples['safety_score'].max():.1f}"
                    if samples["safety_score"].notna().any()
                    else "—",
                )

                chart_left, chart_right = st.columns(2)

                with chart_left:
                    progress_figure = go.Figure()
                    progress_figure.add_trace(
                        go.Scatter(
                            x=samples["timestamp"],
                            y=samples["progress_pct"],
                            mode="lines",
                            line=dict(
                                color="#9b7cff",
                                width=2.5,
                            ),
                            name="Bonding",
                            hovertemplate="%{y:.2f}%<extra></extra>",
                        )
                    )
                    progress_figure.update_layout(
                        **PLOTLY_LAYOUT,
                        height=345,
                        title=(
                            f"{selected_symbol} — progression de courbe"
                        ),
                        showlegend=False,
                        xaxis=dict(showgrid=False),
                        yaxis=dict(
                            gridcolor="rgba(255,255,255,.055)",
                            range=[0, 100],
                            ticksuffix=" %",
                        ),
                    )
                    st.plotly_chart(
                        progress_figure,
                        use_container_width=True,
                        config={"displayModeBar": False},
                    )

                with chart_right:
                    price_samples = samples[
                        samples["curve_price_sol"].notna()
                    ]
                    price_figure = go.Figure()
                    price_figure.add_trace(
                        go.Scatter(
                            x=price_samples["timestamp"],
                            y=price_samples["curve_price_sol"],
                            mode="lines",
                            line=dict(
                                color="#32d7ff",
                                width=2.5,
                            ),
                            name="Prix",
                            hovertemplate="%{y:.12f} SOL<extra></extra>",
                        )
                    )
                    price_figure.update_layout(
                        **PLOTLY_LAYOUT,
                        height=345,
                        title=(
                            f"{selected_symbol} — prix de courbe"
                        ),
                        showlegend=False,
                        xaxis=dict(showgrid=False),
                        yaxis=dict(
                            gridcolor="rgba(255,255,255,.055)",
                            tickformat=".12f",
                        ),
                    )
                    st.plotly_chart(
                        price_figure,
                        use_container_width=True,
                        config={"displayModeBar": False},
                    )

                scores_figure = go.Figure()
                scores_figure.add_trace(
                    go.Scatter(
                        x=samples["timestamp"],
                        y=samples["safety_score"],
                        mode="lines",
                        name="Safety",
                        line=dict(
                            color="#25e6a5",
                            width=2.3,
                        ),
                        hovertemplate="Safety %{y:.1f}<extra></extra>",
                    )
                )
                scores_figure.add_trace(
                    go.Scatter(
                        x=samples["timestamp"],
                        y=samples["qualification_score"],
                        mode="lines",
                        name="Qualification",
                        line=dict(
                            color="#ffbf69",
                            width=2.3,
                        ),
                        hovertemplate="Qualification %{y:.1f}<extra></extra>",
                    )
                )
                scores_figure.update_layout(
                    **PLOTLY_LAYOUT,
                    height=330,
                    title="Évolution des scores",
                    xaxis=dict(showgrid=False),
                    yaxis=dict(
                        gridcolor="rgba(255,255,255,.055)",
                        range=[0, 100],
                    ),
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                    ),
                )
                st.plotly_chart(
                    scores_figure,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

                st.markdown("### Journal événementiel")
                if events.empty:
                    st.info(
                        "Aucun changement d’état enregistré pour ce token."
                    )
                else:
                    st.dataframe(
                        events[
                            [
                                "timestamp",
                                "event_type",
                                "previous_value",
                                "new_value",
                                "source",
                                "details_json",
                            ]
                        ],
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            "timestamp": st.column_config.DatetimeColumn(
                                "Heure",
                                format="DD/MM HH:mm:ss",
                            ),
                            "event_type": "Événement",
                            "previous_value": "Avant",
                            "new_value": "Après",
                            "source": "Source",
                            "details_json": st.column_config.TextColumn(
                                "Détails",
                                width="large",
                            ),
                        },
                    )

        st.divider()
        st.markdown("### Lancer une simulation historique")

        defaults = default_parameters()

        with st.form("backtest_form_v9"):
            left, middle, right = st.columns(3)

            with left:
                test_name = st.text_input(
                    "Nom du test",
                    value=(
                        "Strategy V10.1 "
                        + datetime.now().strftime("%d-%m %H:%M")
                    ),
                )
                initial_capital = st.number_input(
                    "Capital initial (SOL)",
                    min_value=0.1,
                    max_value=100.0,
                    value=float(
                        defaults["initial_capital_sol"]
                    ),
                    step=0.1,
                )
                position_size = st.number_input(
                    "Taille d’une position (SOL)",
                    min_value=0.001,
                    max_value=1.0,
                    value=float(
                        defaults["position_size_sol"]
                    ),
                    step=0.005,
                    format="%.3f",
                )
                min_safety = st.slider(
                    "Safety minimum",
                    min_value=0,
                    max_value=100,
                    value=int(
                        defaults["min_safety_score"]
                    ),
                )

            with middle:
                observation_seconds = st.number_input(
                    "Observation minimale (secondes)",
                    min_value=0,
                    max_value=3600,
                    value=int(
                        defaults["observation_seconds"]
                    ),
                    step=15,
                )
                min_samples = st.number_input(
                    "Échantillons minimum",
                    min_value=1,
                    max_value=100,
                    value=int(defaults["min_samples"]),
                    step=1,
                )
                min_progress = st.number_input(
                    "Bonding minimum (%)",
                    min_value=0.0,
                    max_value=100.0,
                    value=float(
                        defaults["min_progress_pct"]
                    ),
                    step=1.0,
                )
                max_progress = st.number_input(
                    "Bonding maximum (%)",
                    min_value=0.0,
                    max_value=100.0,
                    value=float(
                        defaults["max_progress_pct"]
                    ),
                    step=1.0,
                )

            with right:
                stop_loss = st.number_input(
                    "Stop-loss (%)",
                    min_value=-99.0,
                    max_value=-0.1,
                    value=float(defaults["stop_loss_pct"]),
                    step=1.0,
                )
                take_profit = st.number_input(
                    "Take-profit (%)",
                    min_value=0.1,
                    max_value=1000.0,
                    value=float(
                        defaults["take_profit_pct"]
                    ),
                    step=1.0,
                )
                max_hold = st.number_input(
                    "Durée maximale (minutes)",
                    min_value=1,
                    max_value=1440,
                    value=int(
                        defaults["max_holding_minutes"]
                    ),
                    step=1,
                )
                min_delta = st.number_input(
                    "Progression minimale Δ (%)",
                    min_value=0.0,
                    max_value=100.0,
                    value=float(
                        defaults["min_progress_delta_pct"]
                    ),
                    step=0.1,
                    format="%.2f",
                )

            submitted = st.form_submit_button(
                "Lancer le backtest",
                use_container_width=True,
            )

        if submitted:
            parameters = {
                "initial_capital_sol": initial_capital,
                "position_size_sol": position_size,
                "observation_seconds": observation_seconds,
                "min_samples": min_samples,
                "min_safety_score": min_safety,
                "min_progress_pct": min_progress,
                "max_progress_pct": max_progress,
                "min_progress_delta_pct": min_delta,
                "stop_loss_pct": stop_loss,
                "take_profit_pct": take_profit,
                "max_holding_minutes": max_hold,
            }

            try:
                summary = run_backtest(
                    parameters=parameters,
                    name=test_name,
                    db_path=DB_PATH,
                    save=True,
                )
                st.success(
                    f"Backtest #{summary.run_id} terminé : "
                    f"{summary.trade_count} trade(s), "
                    f"{summary.pnl_sol:+.4f} SOL."
                )
            except Exception as error:
                st.error(f"Échec du backtest : {error}")

        latest_runs = query(
            """
            SELECT *
            FROM backtest_runs
            ORDER BY id DESC
            LIMIT 30
            """
        )
        parse_dates(latest_runs, ["created_at"])

        if latest_runs.empty:
            st.info("Aucun backtest enregistré.")
        else:
            st.markdown("### Résultats enregistrés")
            st.dataframe(
                latest_runs[
                    [
                        "id",
                        "created_at",
                        "name",
                        "sample_count",
                        "candidate_count",
                        "trade_count",
                        "win_rate",
                        "pnl_sol",
                        "return_pct",
                        "max_drawdown_sol",
                        "ending_equity_sol",
                        "status",
                    ]
                ],
                use_container_width=True,
                hide_index=True,
                column_config={
                    "id": "Run",
                    "created_at": st.column_config.DatetimeColumn(
                        "Date",
                        format="DD/MM HH:mm:ss",
                    ),
                    "name": "Nom",
                    "sample_count": "Échantillons",
                    "candidate_count": "Candidats",
                    "trade_count": "Trades",
                    "win_rate": st.column_config.NumberColumn(
                        "Win rate",
                        format="%.1f %%",
                    ),
                    "pnl_sol": st.column_config.NumberColumn(
                        "PnL",
                        format="%+.4f SOL",
                    ),
                    "return_pct": st.column_config.NumberColumn(
                        "Rendement",
                        format="%+.2f %%",
                    ),
                    "max_drawdown_sol": st.column_config.NumberColumn(
                        "Drawdown",
                        format="%.4f SOL",
                    ),
                    "ending_equity_sol": st.column_config.NumberColumn(
                        "Équité finale",
                        format="%.4f SOL",
                    ),
                    "status": "État",
                },
            )

            selected_run_id = st.selectbox(
                "Détails d’un backtest",
                latest_runs["id"].tolist(),
                format_func=lambda run_id: (
                    f"#{run_id} — "
                    f"{latest_runs.loc[latest_runs['id'] == run_id, 'name'].iloc[0]}"
                ),
                key="backtest_run_selector",
            )
            run_trades = query(
                """
                SELECT *
                FROM backtest_trades
                WHERE run_id = ?
                ORDER BY datetime(entry_at)
                """,
                (int(selected_run_id),),
            )
            parse_dates(run_trades, ["entry_at", "exit_at"])

            if run_trades.empty:
                st.info(
                    "Ce scénario n’a trouvé aucune entrée conforme."
                )
            else:
                st.dataframe(
                    run_trades[
                        [
                            "symbol",
                            "entry_at",
                            "exit_at",
                            "entry_progress_pct",
                            "exit_progress_pct",
                            "entry_safety_score",
                            "entry_qualification_score",
                            "pnl_sol",
                            "pnl_pct",
                            "exit_reason",
                            "holding_seconds",
                        ]
                    ],
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "symbol": "Token",
                        "entry_at": st.column_config.DatetimeColumn(
                            "Entrée",
                            format="DD/MM HH:mm:ss",
                        ),
                        "exit_at": st.column_config.DatetimeColumn(
                            "Sortie",
                            format="DD/MM HH:mm:ss",
                        ),
                        "entry_progress_pct": st.column_config.NumberColumn(
                            "Bonding entrée",
                            format="%.2f %%",
                        ),
                        "exit_progress_pct": st.column_config.NumberColumn(
                            "Bonding sortie",
                            format="%.2f %%",
                        ),
                        "entry_safety_score": st.column_config.NumberColumn(
                            "Safety",
                            format="%.1f",
                        ),
                        "entry_qualification_score": st.column_config.NumberColumn(
                            "Qualification",
                            format="%.1f",
                        ),
                        "pnl_sol": st.column_config.NumberColumn(
                            "PnL",
                            format="%+.4f SOL",
                        ),
                        "pnl_pct": st.column_config.NumberColumn(
                            "PnL %",
                            format="%+.2f %%",
                        ),
                        "exit_reason": "Sortie",
                        "holding_seconds": st.column_config.NumberColumn(
                            "Durée",
                            format="%.0f s",
                        ),
                    },
                )

        st.caption(
            "Le backtest V10.1 utilise des observations périodiques de la "
            "bonding curve. Il inclut une approximation des frais, mais ne "
            "reconstruit pas chaque transaction ni la latence réelle."
        )

    elif selected_page == "Pré-bond":
        st.markdown(
            '<div class="section-head"><div class="section-title">Bonding curves Pump.fun</div>'
            '<div class="section-note">Lecture directe des comptes PDA du programme Pump</div></div>',
            unsafe_allow_html=True,
        )
        if latest_bonding.empty:
            st.warning("Aucune donnée on-chain. Vérifie la fenêtre du collecteur.")
        else:
            st.dataframe(
                latest_bonding[
                    [
                        "symbol", "token_name", "lifecycle_state",
                        "progress_pct", "curve_price_sol",
                        "curve_price_usd", "real_quote_reserves_sol",
                        "real_token_reserves_raw", "complete",
                        "is_mayhem_mode", "bonding_curve_address",
                        "rpc_status",
                    ]
                ].sort_values("progress_pct", ascending=False),
                use_container_width=True,
                hide_index=True,
                column_config={
                    "symbol": "Ticker",
                    "token_name": "Nom",
                    "lifecycle_state": "État",
                    "progress_pct": st.column_config.ProgressColumn(
                        "Bonding",
                        min_value=0,
                        max_value=100,
                        format="%.2f %%",
                    ),
                    "curve_price_sol": st.column_config.NumberColumn(
                        "Prix SOL",
                        format="%.12f",
                    ),
                    "curve_price_usd": st.column_config.NumberColumn(
                        "Prix USD",
                        format="$ %.10f",
                    ),
                    "real_quote_reserves_sol": st.column_config.NumberColumn(
                        "SOL réel courbe",
                        format="%.4f",
                    ),
                    "real_token_reserves_raw": st.column_config.NumberColumn(
                        "Tokens restants bruts",
                        format="%d",
                    ),
                    "complete": "Complète",
                    "is_mayhem_mode": "Mayhem",
                    "bonding_curve_address": st.column_config.TextColumn(
                        "PDA",
                        width="large",
                    ),
                    "rpc_status": "Décodage",
                },
            )

            choices = latest_bonding["token_mint"].tolist()
            selected_mint = st.selectbox(
                "Courbe à analyser",
                choices,
                format_func=lambda mint: (
                    f"{latest_bonding.loc[latest_bonding['token_mint'] == mint, 'symbol'].iloc[0]}"
                    f" — {mint[:8]}…{mint[-6:]}"
                ),
                key="bonding_chart",
            )
            history = (
                bonding[bonding["token_mint"] == selected_mint]
                .sort_values("timestamp")
                .tail(1200)
            )

            left, right = st.columns(2)
            with left:
                progress_fig = go.Figure(
                    go.Scatter(
                        x=history["timestamp"],
                        y=history["progress_pct"],
                        mode="lines",
                        line=dict(color="#9b7cff", width=2.5),
                        hovertemplate="%{y:.2f}%<extra></extra>",
                    )
                )
                progress_fig.update_layout(
                    **PLOTLY_LAYOUT,
                    height=350,
                    title="Progression vers la fin de courbe",
                    showlegend=False,
                    xaxis=dict(showgrid=False),
                    yaxis=dict(
                        gridcolor="rgba(255,255,255,.055)",
                        range=[0, 100],
                        ticksuffix=" %",
                    ),
                )
                st.plotly_chart(
                    progress_fig,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

            with right:
                price_history = history[history["curve_price_usd"].notna()]
                price_fig = go.Figure(
                    go.Scatter(
                        x=price_history["timestamp"],
                        y=price_history["curve_price_usd"],
                        mode="lines",
                        line=dict(color="#32d7ff", width=2.5),
                        hovertemplate="$%{y:.10f}<extra></extra>",
                    )
                )
                price_fig.update_layout(
                    **PLOTLY_LAYOUT,
                    height=350,
                    title="Prix calculé depuis les réserves on-chain",
                    showlegend=False,
                    xaxis=dict(showgrid=False),
                    yaxis=dict(
                        gridcolor="rgba(255,255,255,.055)",
                        tickformat=".10f",
                    ),
                )
                st.plotly_chart(
                    price_fig,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

            st.caption(
                "BONDING = courbe active • GRADUATING = courbe complète sans marché DEX "
                "confirmé • BONDED = courbe complète et paire DEX détectée."
            )

    elif selected_page == "Scanner hybride":
        if combined.empty:
            st.info("En attente des données.")
        else:
            display = combined.copy()
            display["prix_actif_usd"] = display["curve_price_usd"].where(
                display["lifecycle_state"] == "BONDING",
                display["price_usd"],
            )
            st.dataframe(
                display[
                    [
                        "symbol", "token_name", "lifecycle_state",
                        "progress_pct", "prix_actif_usd",
                        "change_5m_pct", "liquidity_usd",
                        "volume_5m_usd", "buys_5m", "sells_5m",
                        "score", "rpc_status", "data_status",
                        "source_url",
                    ]
                ].sort_values("score", ascending=False),
                use_container_width=True,
                hide_index=True,
                column_config={
                    "symbol": "Ticker",
                    "token_name": "Nom",
                    "lifecycle_state": "Cycle",
                    "progress_pct": st.column_config.ProgressColumn(
                        "Bonding",
                        min_value=0,
                        max_value=100,
                        format="%.1f %%",
                    ),
                    "prix_actif_usd": st.column_config.NumberColumn(
                        "Prix actif",
                        format="$ %.10f",
                    ),
                    "change_5m_pct": st.column_config.NumberColumn(
                        "5 min",
                        format="%+.2f %%",
                    ),
                    "liquidity_usd": st.column_config.NumberColumn(
                        "Liquidité DEX",
                        format="$ %.0f",
                    ),
                    "volume_5m_usd": st.column_config.NumberColumn(
                        "Volume 5 min",
                        format="$ %.0f",
                    ),
                    "buys_5m": "Achats",
                    "sells_5m": "Ventes",
                    "score": st.column_config.ProgressColumn(
                        "Score recherche",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "rpc_status": "RPC",
                    "data_status": "DEX",
                    "source_url": st.column_config.LinkColumn(
                        "Marché",
                        display_text="Ouvrir",
                    ),
                },
            )

    elif selected_page == "Positions":
        if opened.empty:
            st.info("Aucune position paper ouverte.")
        else:
            view = opened.copy()
            view["pnl_latent_sol"] = (
                view["current_value_sol"]
                - view["entry_sol"]
                - view["entry_fees_sol"]
            )
            view["pnl_latent_pct"] = (
                view["pnl_latent_sol"]
                / (view["entry_sol"] + view["entry_fees_sol"])
                * 100
            )
            st.dataframe(
                view,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "opened_at": st.column_config.DatetimeColumn(
                        "Ouverture",
                        format="DD/MM HH:mm:ss",
                    ),
                    "entry_sol": st.column_config.NumberColumn(
                        "Entrée",
                        format="%.4f SOL",
                    ),
                    "current_value_sol": st.column_config.NumberColumn(
                        "Valeur",
                        format="%.4f SOL",
                    ),
                    "pnl_latent_sol": st.column_config.NumberColumn(
                        "PnL",
                        format="%+.4f SOL",
                    ),
                    "pnl_latent_pct": st.column_config.NumberColumn(
                        "PnL %",
                        format="%+.2f %%",
                    ),
                    "peak_pnl_pct": st.column_config.NumberColumn(
                        "Pic PnL",
                        format="%+.2f %%",
                    ),
                    "break_even_armed": st.column_config.CheckboxColumn(
                        "Break-even"
                    ),
                    "active_stop_pct": st.column_config.NumberColumn(
                        "Stop actif",
                        format="%+.2f %%",
                    ),
                    "entry_bonding_progress_pct": st.column_config.NumberColumn(
                        "Bonding entrée",
                        format="%.1f %%",
                    ),
                },
            )

    elif selected_page == "Historique":
        st.dataframe(
            positions,
            use_container_width=True,
            hide_index=True,
            column_config={
                "opened_at": st.column_config.DatetimeColumn(
                    "Ouverture",
                    format="DD/MM HH:mm:ss",
                ),
                "closed_at": st.column_config.DatetimeColumn(
                    "Fermeture",
                    format="DD/MM HH:mm:ss",
                ),
                "entry_sol": st.column_config.NumberColumn(
                    "Entrée",
                    format="%.4f SOL",
                ),
                "exit_sol": st.column_config.NumberColumn(
                    "Sortie",
                    format="%.4f SOL",
                ),
                "realized_pnl_sol": st.column_config.NumberColumn(
                    "PnL",
                    format="%+.4f SOL",
                ),
                "realized_pnl_pct": st.column_config.NumberColumn(
                    "PnL %",
                    format="%+.2f %%",
                ),
                "source_url": st.column_config.LinkColumn(
                    "Marché",
                    display_text="Ouvrir",
                ),
            },
        )
        st.download_button(
            "Exporter les trades",
            positions.to_csv(index=False).encode("utf-8"),
            "solpulse_prebond_trades.csv",
            "text/csv",
        )

    elif selected_page == "Signaux":
        if signals.empty:
            st.info("Aucun signal paper.")
        else:
            view = signals.copy()
            def decode_reasons(raw: str | None) -> str:
                try:
                    return " • ".join(json.loads(raw)) if raw else ""
                except Exception:
                    return str(raw or "")
            view["raisons"] = view["reasons_json"].apply(decode_reasons)
            st.dataframe(
                view[
                    [
                        "timestamp", "symbol", "lifecycle_state",
                        "decision", "score", "strategy", "raisons",
                    ]
                ],
                use_container_width=True,
                hide_index=True,
                column_config={
                    "timestamp": st.column_config.DatetimeColumn(
                        "Heure",
                        format="DD/MM HH:mm:ss",
                    ),
                    "symbol": "Token",
                    "lifecycle_state": "Cycle",
                    "decision": "Décision",
                    "score": st.column_config.ProgressColumn(
                        "Score",
                        min_value=0,
                        max_value=100,
                        format="%.1f",
                    ),
                    "strategy": "Stratégie",
                    "raisons": st.column_config.TextColumn(
                        "Raisons",
                        width="large",
                    ),
                },
            )

    elif selected_page == "Analytics":
        if closed.empty:
            st.info("Attends la clôture d’au moins un trade paper.")
        else:
            a, b, c, d = st.columns(4)
            a.metric("Trades", len(closed))
            b.metric(
                "Gain moyen",
                fmt_sol(wins["realized_pnl_sol"].mean() if len(wins) else 0),
            )
            c.metric(
                "Perte moyenne",
                fmt_sol(losses["realized_pnl_sol"].mean() if len(losses) else 0),
            )
            d.metric("Espérance", fmt_sol(closed["realized_pnl_sol"].mean()))

            pnl = closed.sort_values("closed_at").copy()
            pnl["trade"] = range(1, len(pnl) + 1)
            fig = go.Figure(
                go.Bar(
                    x=pnl["trade"],
                    y=pnl["realized_pnl_sol"],
                    marker=dict(
                        color=[
                            "#25e6a5" if value >= 0 else "#ff5c78"
                            for value in pnl["realized_pnl_sol"]
                        ]
                    ),
                    hovertemplate="Trade %{x}<br>%{y:+.4f} SOL<extra></extra>",
                )
            )
            fig.update_layout(
                **PLOTLY_LAYOUT,
                height=390,
                title="PnL par trade",
                xaxis=dict(showgrid=False),
                yaxis=dict(
                    gridcolor="rgba(255,255,255,.055)",
                    title="SOL",
                ),
            )
            st.plotly_chart(
                fig,
                use_container_width=True,
                config={"displayModeBar": False},
            )

    elif selected_page == "Exécution":
        if orders.empty:
            st.info("Aucun ordre paper.")
        else:
            filled = orders[orders["status"] == "FILLED"]
            a, b, c, d = st.columns(4)
            a.metric("Ordres", len(orders))
            a_value = (
                filled["extra_slippage_pct"].mean()
                if len(filled)
                else 0
            )
            b.metric("Coût moyen", f"{a_value:.3f} %")
            c.metric(
                "Impact moyen",
                f"{filled['price_impact_pct'].mean():.3f} %"
                if len(filled)
                else "0 %",
            )
            d.metric(
                "Bonding / DEX",
                f"{(orders['market_mode'] == 'BONDING').sum()} / "
                f"{(orders['market_mode'] == 'DEX').sum()}",
            )
            st.dataframe(
                orders,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "timestamp": st.column_config.DatetimeColumn(
                        "Heure",
                        format="DD/MM HH:mm:ss",
                    ),
                    "requested_sol": st.column_config.NumberColumn(
                        "Demandé",
                        format="%.4f SOL",
                    ),
                    "price_impact_pct": st.column_config.NumberColumn(
                        "Impact",
                        format="%.3f %%",
                    ),
                    "extra_slippage_pct": st.column_config.NumberColumn(
                        "Coût",
                        format="%.3f %%",
                    ),
                },
            )

    elif selected_page == "Watchlist":
        watch_df = pd.DataFrame(watchlist["tokens"])
        if not combined.empty:
            metadata = combined[
                [
                    "token_mint", "symbol", "token_name",
                    "lifecycle_state", "bonding_curve_address",
                    "rpc_status", "source_url",
                ]
            ]
            watch_df = watch_df.merge(
                metadata,
                left_on="address",
                right_on="token_mint",
                how="left",
            )
        st.dataframe(
            watch_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "address": st.column_config.TextColumn(
                    "Mint",
                    width="large",
                ),
                "label": "Nom provisoire",
                "symbol": "Ticker",
                "token_name": "Nom",
                "lifecycle_state": "Cycle",
                "bonding_curve_address": st.column_config.TextColumn(
                    "PDA bonding curve",
                    width="large",
                ),
                "rpc_status": "RPC",
                "source_url": st.column_config.LinkColumn(
                    "DEX",
                    display_text="Ouvrir",
                ),
            },
        )
        st.caption(
            "Cette version vérifie les cinq contrats de la watchlist. "
            "La découverte automatique de tous les nouveaux launches viendra ensuite."
        )


if not DB_PATH.exists():
    st.error("Base absente. Lance 02_REINITIALISER_1_SOL.bat.")
else:
    render_live(page)

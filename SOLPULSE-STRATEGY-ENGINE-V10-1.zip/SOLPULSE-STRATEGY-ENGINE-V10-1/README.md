
# SOLPULSE STRATEGY ENGINE V10.1

V10.1 corrige précisément le calcul de la limite de détention demandée.

## Règle corrigée

Pour chaque propriétaire hors pool :

```text
pourcentage du holder =
tokens détenus par ce propriétaire / supply totale du token
```

La bonding curve ou la liquidity pool :

- est ignorée dans le classement des holders ;
- peut détenir plus de 3,5 % sans provoquer de rejet ;
- reste incluse dans la supply totale utilisée comme dénominateur.

Exemple :

```text
Supply totale : 100 %
Pool : 22 %                  → ignorée
Wallet A : 3,2 %             → accepté
Wallet B : 2,7 %             → accepté
Wallet C : 3,51 %            → rejet
```

V10 calculait auparavant la part du wallet sur la supply restante après retrait
de la pool. Un wallet affiché à 3,2 % pouvait donc être interprété comme
`3,2 / 78 = 4,10 %`. V10.1 supprime cette erreur.

Les token accounts appartenant au même propriétaire sont toujours regroupés
avant le calcul.

## Autres règles inchangées

- lancements du créateur : informatifs uniquement ;
- holder hors pool : 3,5 % maximum de la supply totale ;
- position paper : 0,05 SOL ;
- une seule position simultanée ;
- stop initial : -20 % ;
- take-profit : +100 % ;
- break-even armé après un pic à +50 % ;
- stop remonté à +1 % après armement ;
- frais de courbe simulés : 1,25 % par côté ;
- frais réseau simulés : 0,000005 SOL ;
- aucune transaction réelle.

## Installer sans historique

1. Fermer toutes les anciennes fenêtres SOLPULSE.
2. Décompresser entièrement l’archive.
3. Ouvrir `SOLPULSE-STRATEGY-ENGINE-V10-1`.
4. Double-cliquer sur `01_START_STRATEGY_ENGINE_V10_1.bat`.
5. Ouvrir uniquement :

   `http://localhost:8518/?version=STRATEGY-ENGINE-V10-1`

## Récupérer l’historique V9 ou V10

1. Fermer complètement l’ancienne version et V10.1.
2. Double-cliquer sur `03_IMPORTER_BASE_PRECEDENTE.bat`.
3. Sélectionner le fichier `data\trading.db` de V9 ou V10.
4. Attendre le message de confirmation.
5. Lancer `01_START_STRATEGY_ENGINE_V10_1.bat`.

L’import crée une sauvegarde avant de modifier la base. Les coins analysés,
positions paper, événements et backtests sont conservés.

Ne lance pas `02_REINITIALISER_1_SOL.bat` si tu souhaites garder cet historique.

## Limite actuelle

Le filtre regroupe les propriétaires à partir des vingt plus gros token accounts
renvoyés par le RPC Solana. Il ignore correctement la pool, mais il ne peut pas
encore prouver que plusieurs wallets distincts appartiennent à une même personne.
Cette détection nécessitera le futur module Wallet & Flow Intelligence.

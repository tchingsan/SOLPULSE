
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import math
import os
import sqlite3
import struct
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, urlunparse

import httpx
import websockets

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "trading.db"
CONFIG_PATH = BASE_DIR / "config.json"
WATCHLIST_PATH = BASE_DIR / "watchlist.json"
LOCK_PATH = BASE_DIR / "data" / "new_coin_radar.lock"

PUMP_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
GLOBAL_ACCOUNT = "4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf"

CREATE_EVENT_DISCRIMINATOR = bytes(
    [27, 114, 169, 77, 222, 235, 99, 118]
)
BONDING_CURVE_DISCRIMINATOR = bytes(
    [23, 183, 248, 55, 96, 216, 172, 96]
)
GLOBAL_DISCRIMINATOR = hashlib.sha256(
    b"account:Global"
).digest()[:8]

LAMPORTS_PER_SOL = 1_000_000_000
TOKEN_DECIMALS = 6
FALLBACK_INITIAL_REAL_TOKEN_RESERVES = 793_100_000_000_000

BASE58_ALPHABET = (
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
)

running = True


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def connect_db() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=5000")
    return connection


def write_state(
    connection: sqlite3.Connection,
    key: str,
    value: str,
) -> None:
    connection.execute(
        """
        INSERT INTO bot_state(key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now_iso()),
    )


def acquire_lock() -> None:
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)

    if LOCK_PATH.exists():
        age = datetime.now().timestamp() - LOCK_PATH.stat().st_mtime
        if age < 30:
            print("Le New Coin Radar semble déjà fonctionner.")
            sys.exit(1)
        LOCK_PATH.unlink(missing_ok=True)

    LOCK_PATH.write_text(str(os.getpid()), encoding="utf-8")


def release_lock() -> None:
    LOCK_PATH.unlink(missing_ok=True)


def b58encode(value: bytes) -> str:
    zero_count = len(value) - len(value.lstrip(b"\x00"))
    number = int.from_bytes(value, "big")
    encoded = ""

    while number:
        number, remainder = divmod(number, 58)
        encoded = BASE58_ALPHABET[remainder] + encoded

    return "1" * zero_count + encoded


def read_borsh_string(
    payload: bytes,
    offset: int,
) -> tuple[str, int]:
    if offset + 4 > len(payload):
        raise ValueError("Longueur Borsh absente.")

    length = struct.unpack_from("<I", payload, offset)[0]
    offset += 4

    if length > 16_384 or offset + length > len(payload):
        raise ValueError("Chaîne Borsh invalide.")

    raw = payload[offset : offset + length]
    return raw.decode("utf-8", errors="replace"), offset + length


def decode_create_event(payload: bytes) -> dict[str, str] | None:
    if len(payload) < 8 or payload[:8] != CREATE_EVENT_DISCRIMINATOR:
        return None

    offset = 8
    name, offset = read_borsh_string(payload, offset)
    symbol, offset = read_borsh_string(payload, offset)
    uri, offset = read_borsh_string(payload, offset)

    if offset + 96 > len(payload):
        raise ValueError("CreateEvent incomplet.")

    mint = b58encode(payload[offset : offset + 32])
    offset += 32
    bonding_curve = b58encode(payload[offset : offset + 32])
    offset += 32
    creator = b58encode(payload[offset : offset + 32])

    return {
        "name": name[:256],
        "symbol": symbol[:64],
        "uri": uri[:2048],
        "mint": mint,
        "bonding_curve": bonding_curve,
        "creator": creator,
    }


def extract_create_events(
    logs: list[str] | None,
) -> list[dict[str, str]]:
    events: list[dict[str, str]] = []

    for log in logs or []:
        if not log.startswith("Program data: "):
            continue

        encoded = log.removeprefix("Program data: ").strip()
        try:
            payload = base64.b64decode(encoded, validate=True)
            event = decode_create_event(payload)
        except (ValueError, struct.error):
            event = None

        if event:
            events.append(event)

    return events


def safe_detected_at(block_time: int | None) -> str:
    if block_time:
        try:
            return datetime.fromtimestamp(
                block_time,
                tz=timezone.utc,
            ).isoformat()
        except (ValueError, OSError):
            pass
    return now_iso()


def watchlist_mints() -> set[str]:
    try:
        watchlist = load_json(WATCHLIST_PATH)
        return {
            str(token["address"])
            for token in watchlist.get("tokens", [])
            if token.get("address")
        }
    except Exception:
        return set()


def save_launches(
    signature: str,
    slot: int | None,
    logs: list[str] | None,
    block_time: int | None = None,
) -> int:
    events = extract_create_events(logs)
    if not events:
        return 0

    added = 0
    known_watchlist = watchlist_mints()

    with connect_db() as connection:
        for event_index, event in enumerate(events):
            existed = connection.execute(
                "SELECT 1 FROM new_launches WHERE mint = ?",
                (event["mint"],),
            ).fetchone()

            connection.execute(
                """
                INSERT INTO new_launches (
                    detected_at, last_updated_at,
                    slot, signature, event_index,
                    mint, name, symbol, uri,
                    bonding_curve, creator,
                    lifecycle_state, progress_pct,
                    curve_price_sol, curve_price_usd,
                    real_quote_reserves_sol,
                    complete, account_exists, rpc_status,
                    is_in_watchlist, source
                )
                VALUES (?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        'DETECTED', NULL, NULL, NULL, NULL,
                        NULL, NULL, 'WAITING', ?, 'Pump CreateEvent')
                ON CONFLICT(mint) DO UPDATE SET
                    name = excluded.name,
                    symbol = excluded.symbol,
                    uri = excluded.uri,
                    bonding_curve = excluded.bonding_curve,
                    creator = excluded.creator,
                    is_in_watchlist = excluded.is_in_watchlist
                """,
                (
                    safe_detected_at(block_time),
                    slot,
                    signature,
                    event_index,
                    event["mint"],
                    event["name"],
                    event["symbol"],
                    event["uri"],
                    event["bonding_curve"],
                    event["creator"],
                    int(event["mint"] in known_watchlist),
                ),
            )
            if not existed:
                added += 1

        total = connection.execute(
            "SELECT COUNT(*) FROM new_launches"
        ).fetchone()[0]
        write_state(connection, "radar_last_event", now_iso())
        write_state(
            connection,
            "radar_launches_detected",
            str(total),
        )
        connection.commit()

    return added


def websocket_url(http_url: str) -> str:
    parsed = urlparse(http_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse(parsed._replace(scheme=scheme))


async def rpc_call(
    client: httpx.AsyncClient,
    method: str,
    params: list[Any],
) -> Any:
    response = await client.post(
        "",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        },
        headers={"Content-Type": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()

    if payload.get("error"):
        raise RuntimeError(f"{method}: {payload['error']}")

    return payload.get("result")


def decode_u64(data: bytes, offset: int) -> int:
    if offset + 8 > len(data):
        raise ValueError("Compte trop court.")
    return struct.unpack_from("<Q", data, offset)[0]


def decode_global_initial_reserves(
    account: dict[str, Any] | None,
) -> int:
    if not account:
        return FALLBACK_INITIAL_REAL_TOKEN_RESERVES

    try:
        raw = base64.b64decode(account["data"][0])
        if len(raw) < 97 or raw[:8] != GLOBAL_DISCRIMINATOR:
            return FALLBACK_INITIAL_REAL_TOKEN_RESERVES

        value = decode_u64(raw, 89)
        return value or FALLBACK_INITIAL_REAL_TOKEN_RESERVES
    except Exception:
        return FALLBACK_INITIAL_REAL_TOKEN_RESERVES


def decode_curve_account(
    account: dict[str, Any] | None,
    initial_real_reserves: int,
    sol_price_usd: float,
) -> dict[str, Any]:
    empty = {
        "account_exists": 0,
        "lifecycle_state": "NO_ACCOUNT",
        "progress_pct": None,
        "curve_price_sol": None,
        "curve_price_usd": None,
        "real_quote_reserves_sol": None,
        "complete": None,
        "rpc_status": "NO_ACCOUNT",
    }

    if not account:
        return empty

    try:
        raw = base64.b64decode(account["data"][0])
        owner_valid = account.get("owner") == PUMP_PROGRAM_ID

        if len(raw) < 49:
            return {
                **empty,
                "account_exists": 1,
                "rpc_status": "ACCOUNT_TOO_SHORT",
            }

        discriminator_valid = raw[:8] == BONDING_CURVE_DISCRIMINATOR
        virtual_token = decode_u64(raw, 8)
        virtual_quote = decode_u64(raw, 16)
        real_token = decode_u64(raw, 24)
        real_quote = decode_u64(raw, 32)
        complete = int(bool(raw[48]))

        progress = (
            1.0 - real_token / max(initial_real_reserves, 1)
        ) * 100.0
        progress = max(0.0, min(100.0, progress))

        curve_price_sol = None
        if virtual_token > 0:
            curve_price_sol = (
                virtual_quote / LAMPORTS_PER_SOL
            ) / (
                virtual_token / (10**TOKEN_DECIMALS)
            )

        return {
            "account_exists": 1,
            "lifecycle_state": (
                "CURVE_COMPLETE" if complete else "BONDING"
            ),
            "progress_pct": progress,
            "curve_price_sol": curve_price_sol,
            "curve_price_usd": (
                curve_price_sol * sol_price_usd
                if curve_price_sol and sol_price_usd
                else None
            ),
            "real_quote_reserves_sol": (
                real_quote / LAMPORTS_PER_SOL
            ),
            "complete": complete,
            "rpc_status": (
                "OK"
                if owner_valid and discriminator_valid
                else "UNVERIFIED_ACCOUNT"
            ),
        }
    except Exception:
        return {
            **empty,
            "account_exists": 1,
            "rpc_status": "DECODE_ERROR",
        }


async def fetch_accounts(
    client: httpx.AsyncClient,
    addresses: list[str],
) -> list[dict[str, Any] | None]:
    result = await rpc_call(
        client,
        "getMultipleAccounts",
        [
            addresses,
            {
                "encoding": "base64",
                "commitment": "confirmed",
            },
        ],
    )
    return (result or {}).get("value", [])


async def enrich_recent_launches(
    rpc_client: httpx.AsyncClient,
    track_limit: int,
) -> None:
    with connect_db() as connection:
        launches = connection.execute(
            """
            SELECT id, mint, bonding_curve
            FROM new_launches
            ORDER BY datetime(detected_at) DESC
            LIMIT ?
            """,
            (track_limit,),
        ).fetchall()

        sol_row = connection.execute(
            "SELECT value FROM bot_state WHERE key='sol_price_usd'"
        ).fetchone()
        sol_price_usd = (
            float(sol_row["value"])
            if sol_row and sol_row["value"]
            else 0.0
        )

    if not launches:
        return

    global_accounts = await fetch_accounts(
        rpc_client,
        [GLOBAL_ACCOUNT],
    )
    initial_reserves = decode_global_initial_reserves(
        global_accounts[0] if global_accounts else None
    )

    launch_by_curve = {
        row["bonding_curve"]: row
        for row in launches
    }
    curves = list(launch_by_curve)
    decoded_by_id: dict[int, dict[str, Any]] = {}

    for start in range(0, len(curves), 100):
        chunk = curves[start : start + 100]
        accounts = await fetch_accounts(rpc_client, chunk)

        for curve, account in zip(chunk, accounts):
            row = launch_by_curve[curve]
            decoded_by_id[row["id"]] = decode_curve_account(
                account,
                initial_reserves,
                sol_price_usd,
            )

    current_watchlist = watchlist_mints()

    with connect_db() as connection:
        for row in launches:
            decoded = decoded_by_id.get(row["id"])
            if not decoded:
                continue

            connection.execute(
                """
                UPDATE new_launches
                SET last_updated_at = ?,
                    lifecycle_state = ?,
                    progress_pct = ?,
                    curve_price_sol = ?,
                    curve_price_usd = ?,
                    real_quote_reserves_sol = ?,
                    complete = ?,
                    account_exists = ?,
                    rpc_status = ?,
                    is_in_watchlist = ?
                WHERE id = ?
                """,
                (
                    now_iso(),
                    decoded["lifecycle_state"],
                    decoded["progress_pct"],
                    decoded["curve_price_sol"],
                    decoded["curve_price_usd"],
                    decoded["real_quote_reserves_sol"],
                    decoded["complete"],
                    decoded["account_exists"],
                    decoded["rpc_status"],
                    int(row["mint"] in current_watchlist),
                    row["id"],
                ),
            )

        connection.commit()


async def backfill_recent_transactions(
    rpc_client: httpx.AsyncClient,
    limit: int,
) -> int:
    if limit <= 0:
        return 0

    signatures = await rpc_call(
        rpc_client,
        "getSignaturesForAddress",
        [
            PUMP_PROGRAM_ID,
            {
                "limit": min(limit, 50),
                "commitment": "confirmed",
            },
        ],
    )

    added = 0
    for item in reversed(signatures or []):
        signature = item.get("signature")
        if not signature or item.get("err"):
            continue

        transaction = await rpc_call(
            rpc_client,
            "getTransaction",
            [
                signature,
                {
                    "encoding": "json",
                    "commitment": "confirmed",
                    "maxSupportedTransactionVersion": 0,
                },
            ],
        )
        if not transaction:
            continue

        logs = (
            (transaction.get("meta") or {}).get("logMessages")
            or []
        )
        added += save_launches(
            signature=signature,
            slot=transaction.get("slot"),
            logs=logs,
            block_time=transaction.get("blockTime"),
        )
        await asyncio.sleep(0.08)

    return added


async def subscribe_and_listen(
    ws_url: str,
    rpc_client: httpx.AsyncClient,
    commitment: str,
    enrichment_seconds: float,
    track_limit: int,
) -> None:
    async with websockets.connect(
        ws_url,
        ping_interval=20,
        ping_timeout=20,
        close_timeout=10,
        max_size=4_000_000,
    ) as websocket:
        await websocket.send(
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "logsSubscribe",
                    "params": [
                        {
                            "mentions": [PUMP_PROGRAM_ID],
                        },
                        {
                            "commitment": commitment,
                        },
                    ],
                }
            )
        )

        confirmation = json.loads(await websocket.recv())
        if "error" in confirmation:
            raise RuntimeError(
                f"logsSubscribe: {confirmation['error']}"
            )

        with connect_db() as connection:
            write_state(connection, "radar_status", "RUNNING")
            write_state(connection, "radar_last_error", "")
            connection.commit()

        print(
            f"Abonnement logsSubscribe actif : "
            f"{confirmation.get('result')}"
        )

        loop = asyncio.get_running_loop()
        next_enrichment = loop.time()

        while running:
            timeout = max(
                0.5,
                min(10.0, next_enrichment - loop.time()),
            )

            try:
                raw_message = await asyncio.wait_for(
                    websocket.recv(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                raw_message = None

            if raw_message:
                message = json.loads(raw_message)

                if message.get("method") == "logsNotification":
                    result = (
                        message.get("params", {})
                        .get("result", {})
                    )
                    context = result.get("context", {})
                    value = result.get("value", {})

                    if not value.get("err"):
                        added = save_launches(
                            signature=str(value.get("signature", "")),
                            slot=context.get("slot"),
                            logs=value.get("logs") or [],
                        )
                        if added:
                            print(
                                f"{datetime.now().strftime('%H:%M:%S')} | "
                                f"{added} nouveau(x) lancement(s)"
                            )

            if loop.time() >= next_enrichment:
                await enrich_recent_launches(
                    rpc_client,
                    track_limit,
                )
                next_enrichment = (
                    loop.time() + enrichment_seconds
                )

                with connect_db() as connection:
                    write_state(
                        connection,
                        "radar_status",
                        "RUNNING",
                    )
                    connection.commit()


async def main() -> None:
    global running

    if not DB_PATH.exists():
        print("Base absente. Lance 02_REINITIALISER_1_SOL.bat.")
        return

    config = load_json(CONFIG_PATH)
    if not config.get("radar_enabled", True):
        print("Le radar est désactivé dans config.json.")
        return

    rpc_url = os.getenv(
        "SOLANA_RPC_URL",
        str(config.get("solana_rpc_url")),
    )
    configured_ws = str(
        config.get("solana_ws_url") or ""
    ).strip()
    ws_url = configured_ws or websocket_url(rpc_url)

    commitment = str(
        config.get("radar_commitment", "confirmed")
    )
    backfill_limit = int(
        config.get("radar_backfill_signatures", 15)
    )
    track_limit = int(
        config.get("radar_track_limit", 100)
    )
    enrichment_seconds = float(
        config.get("radar_enrichment_seconds", 10)
    )

    acquire_lock()

    print("=" * 70)
    print("SOLPULSE V10.1 — NEW COIN RADAR")
    print("=" * 70)
    print(f"WebSocket : {ws_url}")
    print(f"RPC HTTP  : {rpc_url}")
    print("Écoute des CreateEvent du programme Pump.")
    print("Aucun achat automatique depuis le radar.")
    print()

    rpc_client = httpx.AsyncClient(
        base_url=rpc_url,
        timeout=httpx.Timeout(20.0),
    )

    try:
        try:
            added = await backfill_recent_transactions(
                rpc_client,
                backfill_limit,
            )
            print(
                f"Backfill terminé : "
                f"{added} lancement(s) ajouté(s)."
            )
        except Exception as error:
            print(f"Backfill non disponible : {error}")

        reconnect_delay = 2.0

        while running:
            try:
                await subscribe_and_listen(
                    ws_url=ws_url,
                    rpc_client=rpc_client,
                    commitment=commitment,
                    enrichment_seconds=enrichment_seconds,
                    track_limit=track_limit,
                )
                reconnect_delay = 2.0
            except asyncio.CancelledError:
                raise
            except KeyboardInterrupt:
                running = False
            except Exception as error:
                message = str(error)
                print(
                    f"WebSocket interrompu : {message}\n"
                    f"Nouvelle tentative dans "
                    f"{reconnect_delay:.0f} secondes."
                )

                with connect_db() as connection:
                    write_state(
                        connection,
                        "radar_status",
                        "RECONNECTING",
                    )
                    write_state(
                        connection,
                        "radar_last_error",
                        message[:500],
                    )
                    connection.commit()

                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(
                    reconnect_delay * 1.8,
                    30.0,
                )
    finally:
        await rpc_client.aclose()
        with connect_db() as connection:
            write_state(
                connection,
                "radar_status",
                "STOPPED",
            )
            connection.commit()
        release_lock()
        print("New Coin Radar arrêté proprement.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        running = False

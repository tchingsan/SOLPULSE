
from __future__ import annotations

import base64
import json
import math
import os
import sqlite3
import struct
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "trading.db"
CONFIG_PATH = BASE_DIR / "config.json"
LOCK_PATH = BASE_DIR / "data" / "qualification_pipeline.lock"

PUMP_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
BONDING_CURVE_DISCRIMINATOR = bytes(
    [23, 183, 248, 55, 96, 216, 172, 96]
)

LAMPORTS_PER_SOL = 1_000_000_000
TOKEN_DECIMALS = 6
STRATEGY = "strategy_engine_v10"

running = True


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def now_iso() -> str:
    return now_utc().isoformat()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def to_float(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def connect_db() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=10000")
    return connection


def write_state(
    connection: sqlite3.Connection,
    key: str,
    value: str,
) -> None:
    connection.execute(
        """
        INSERT INTO bot_state(key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now_iso()),
    )


def acquire_lock() -> None:
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)

    if LOCK_PATH.exists():
        age = time.time() - LOCK_PATH.stat().st_mtime
        if age < 30:
            print("Le Qualification Pipeline semble déjà fonctionner.")
            sys.exit(1)
        LOCK_PATH.unlink(missing_ok=True)

    LOCK_PATH.write_text(str(os.getpid()), encoding="utf-8")


def release_lock() -> None:
    LOCK_PATH.unlink(missing_ok=True)


def rpc_call(
    client: httpx.Client,
    method: str,
    params: list[Any],
) -> Any:
    response = client.post(
        "",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        },
        headers={"Content-Type": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()

    if payload.get("error"):
        raise RuntimeError(f"{method}: {payload['error']}")

    return payload.get("result")


def fetch_curve_accounts(
    client: httpx.Client,
    curves: list[str],
) -> dict[str, dict[str, Any] | None]:
    if not curves:
        return {}

    result_map: dict[str, dict[str, Any] | None] = {}

    for start in range(0, len(curves), 100):
        chunk = curves[start : start + 100]
        result = rpc_call(
            client,
            "getMultipleAccounts",
            [
                chunk,
                {
                    "encoding": "base64",
                    "commitment": "confirmed",
                },
            ],
        )
        accounts = (result or {}).get("value") or []

        for curve, account in zip(chunk, accounts):
            result_map[curve] = account

    return result_map


def decode_u64(data: bytes, offset: int) -> int:
    if offset + 8 > len(data):
        raise ValueError("Compte bonding curve trop court.")
    return struct.unpack_from("<Q", data, offset)[0]


def decode_curve(
    account: dict[str, Any] | None,
) -> dict[str, Any]:
    empty = {
        "valid": False,
        "complete": False,
        "virtual_token_raw": 0,
        "virtual_quote_raw": 0,
        "real_token_raw": 0,
        "real_quote_raw": 0,
        "price_sol": 0.0,
        "real_quote_sol": 0.0,
        "status": "NO_ACCOUNT",
    }

    if not account:
        return empty

    try:
        raw = base64.b64decode(account["data"][0])
    except Exception:
        return {**empty, "status": "BAD_BASE64"}

    if len(raw) < 49:
        return {**empty, "status": "ACCOUNT_TOO_SHORT"}

    owner_valid = account.get("owner") == PUMP_PROGRAM_ID
    discriminator_valid = raw[:8] == BONDING_CURVE_DISCRIMINATOR

    try:
        virtual_token = decode_u64(raw, 8)
        virtual_quote = decode_u64(raw, 16)
        real_token = decode_u64(raw, 24)
        real_quote = decode_u64(raw, 32)
        complete = bool(raw[48])

        price_sol = 0.0
        if virtual_token > 0:
            price_sol = (
                virtual_quote / LAMPORTS_PER_SOL
            ) / (
                virtual_token / (10**TOKEN_DECIMALS)
            )

        return {
            "valid": bool(owner_valid and discriminator_valid),
            "complete": complete,
            "virtual_token_raw": virtual_token,
            "virtual_quote_raw": virtual_quote,
            "real_token_raw": real_token,
            "real_quote_raw": real_quote,
            "price_sol": price_sol,
            "real_quote_sol": real_quote / LAMPORTS_PER_SOL,
            "status": (
                "OK"
                if owner_valid and discriminator_valid
                else "UNVERIFIED_ACCOUNT"
            ),
        }
    except (ValueError, struct.error):
        return {**empty, "status": "DECODE_ERROR"}


def constant_product_buy_quote(
    curve: dict[str, Any],
    amount_sol: float,
    fee_bps: int,
) -> tuple[float, float, float]:
    virtual_token = int(curve["virtual_token_raw"])
    virtual_quote = int(curve["virtual_quote_raw"])
    real_token = int(curve["real_token_raw"])

    gross_quote_raw = int(amount_sol * LAMPORTS_PER_SOL)
    net_quote_raw = int(
        gross_quote_raw * (10_000 - fee_bps) / 10_000
    )

    if (
        virtual_token <= 0
        or virtual_quote <= 0
        or real_token <= 0
        or net_quote_raw <= 0
    ):
        return 0.0, 0.0, 0.0

    invariant = virtual_token * virtual_quote
    new_virtual_quote = virtual_quote + net_quote_raw
    new_virtual_token = (
        invariant + new_virtual_quote - 1
    ) // new_virtual_quote

    token_out_raw = max(
        0,
        virtual_token - new_virtual_token,
    )
    token_out_raw = min(token_out_raw, real_token)
    tokens_out = token_out_raw / (10**TOKEN_DECIMALS)

    spot_price = (
        virtual_quote / LAMPORTS_PER_SOL
    ) / (
        virtual_token / (10**TOKEN_DECIMALS)
    )
    effective_price = (
        amount_sol / tokens_out
        if tokens_out > 0
        else 0.0
    )
    impact_pct = (
        (effective_price / spot_price - 1.0) * 100.0
        if spot_price > 0 and effective_price > 0
        else 0.0
    )

    return (
        tokens_out,
        effective_price,
        max(0.0, impact_pct),
    )


def constant_product_sell_quote(
    curve: dict[str, Any],
    tokens: float,
    fee_bps: int,
) -> tuple[float, float]:
    virtual_token = int(curve["virtual_token_raw"])
    virtual_quote = int(curve["virtual_quote_raw"])
    token_in_raw = int(tokens * (10**TOKEN_DECIMALS))

    if (
        virtual_token <= 0
        or virtual_quote <= 0
        or token_in_raw <= 0
    ):
        return 0.0, 0.0

    invariant = virtual_token * virtual_quote
    new_virtual_token = virtual_token + token_in_raw
    new_virtual_quote = invariant // new_virtual_token
    gross_quote_raw = max(
        0,
        virtual_quote - new_virtual_quote,
    )
    net_quote_raw = int(
        gross_quote_raw * (10_000 - fee_bps) / 10_000
    )
    output_sol = net_quote_raw / LAMPORTS_PER_SOL

    spot_value = tokens * (
        virtual_quote / LAMPORTS_PER_SOL
    ) / (
        virtual_token / (10**TOKEN_DECIMALS)
    )
    impact_pct = (
        max(0.0, (1.0 - output_sol / spot_value) * 100.0)
        if spot_value > 0
        else 0.0
    )

    return output_sol, impact_pct


def latest_portfolio(
    connection: sqlite3.Connection,
) -> sqlite3.Row:
    row = connection.execute(
        """
        SELECT *
        FROM portfolio_snapshots
        ORDER BY id DESC
        LIMIT 1
        """
    ).fetchone()

    if row is None:
        raise RuntimeError("Portefeuille non initialisé.")

    return row


def record_transition(
    connection: sqlite3.Connection,
    mint: str,
    symbol: str | None,
    previous_state: str | None,
    new_state: str,
    qualification_score: float,
    reason: str,
) -> None:
    if previous_state == new_state:
        return

    connection.execute(
        """
        INSERT INTO qualification_events (
            timestamp, mint, symbol,
            previous_state, new_state,
            qualification_score, reason
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            now_iso(),
            mint,
            symbol,
            previous_state,
            new_state,
            qualification_score,
            reason,
        ),
    )


def load_sources() -> list[sqlite3.Row]:
    with connect_db() as connection:
        return connection.execute(
            """
            SELECT
                launches.*,
                safety.assessed_at AS safety_assessed_at,
                safety.safety_score,
                safety.decision AS safety_decision,
                safety.hard_reject,
                safety.analysis_status,
                safety.creator_launch_count,
                candidates.id AS candidate_id,
                candidates.first_qualified_at,
                candidates.last_sample_at,
                candidates.ready_at,
                candidates.state AS candidate_state,
                candidates.qualification_score,
                candidates.observation_samples,
                candidates.stable_samples,
                candidates.initial_progress_pct,
                candidates.current_progress_pct,
                candidates.progress_delta_pct,
                candidates.initial_price_sol,
                candidates.current_price_sol,
                candidates.price_change_pct,
                candidates.min_safety_score,
                candidates.max_safety_score,
                candidates.position_id
            FROM new_launches launches
            LEFT JOIN safety_assessments safety
                ON safety.mint = launches.mint
            LEFT JOIN qualification_candidates candidates
                ON candidates.mint = launches.mint
            WHERE safety.mint IS NOT NULL
               OR candidates.mint IS NOT NULL
            ORDER BY datetime(launches.detected_at) DESC
            LIMIT 500
            """
        ).fetchall()


def load_open_pipeline_positions() -> list[sqlite3.Row]:
    with connect_db() as connection:
        return connection.execute(
            """
            SELECT positions.*, launches.bonding_curve
            FROM positions
            LEFT JOIN new_launches launches
                ON launches.mint = positions.token_mint
            WHERE positions.status = 'OPEN'
              AND positions.strategy = ?
            ORDER BY positions.id
            """,
            (STRATEGY,),
        ).fetchall()


def qualification_score(
    safety_score: float,
    progress_delta: float,
    stable_samples: int,
    creator_launch_count: int,
    price_change_pct: float,
) -> float:
    # Le nombre de lancements du créateur est volontairement ignoré
    # dans V10. Il reste enregistré uniquement pour l'analyse.
    del creator_launch_count

    score = safety_score
    score += min(max(progress_delta, 0.0) * 1.8, 14.0)
    score += min(stable_samples, 10) * 0.9

    if price_change_pct > 15:
        score -= (price_change_pct - 15) * 1.0
    elif price_change_pct < -3:
        score -= abs(price_change_pct + 3) * 1.5

    return max(0.0, min(100.0, score))


def synchronize_candidates(
    connection: sqlite3.Connection,
    rows: list[sqlite3.Row],
    curves: dict[str, dict[str, Any]],
    config: dict[str, Any],
) -> None:
    current_time = now_utc()
    minimum_safety = float(
        config["qualification_min_safety_score"]
    )
    minimum_samples = int(
        config["qualification_min_samples"]
    )
    standard_observation_seconds = float(
        config["qualification_observation_seconds"]
    )
    fast_observation_seconds = float(
        config["qualification_fast_observation_seconds"]
    )
    minimum_progress = float(
        config["qualification_min_progress_pct"]
    )
    maximum_progress = float(
        config["qualification_max_progress_pct"]
    )
    minimum_delta = float(
        config["qualification_min_progress_delta_pct"]
    )
    fast_progress_delta = float(
        config["qualification_fast_progress_delta_pct"]
    )
    maximum_price_change = float(
        config["qualification_max_price_change_pct"]
    )
    fast_max_price_change = float(
        config["qualification_fast_max_price_change_pct"]
    )
    minimum_stable_ratio = float(
        config["qualification_min_stable_ratio"]
    )
    minimum_qualification_score = float(
        config["qualification_min_score"]
    )
    maximum_safety_age = float(
        config["qualification_max_safety_age_seconds"]
    )

    for row in rows:
        mint = str(row["mint"])
        symbol = str(row["symbol"] or "")
        curve_address = str(row["bonding_curve"] or "")
        curve = curves.get(curve_address, {})
        curve_price = to_float(curve.get("price_sol"))
        progress = to_float(row["progress_pct"], -1.0)
        safety_score = to_float(row["safety_score"])
        safety_decision = str(
            row["safety_decision"] or "PENDING"
        )
        analysis_status = str(
            row["analysis_status"] or "PENDING"
        )
        hard_reject = bool(row["hard_reject"])
        creator_count = to_int(
            row["creator_launch_count"],
            0,
        )

        previous_state = (
            str(row["candidate_state"])
            if row["candidate_state"]
            else None
        )

        # Existing paper positions are controlled by the position manager.
        if previous_state == "PAPER_POSITION":
            continue

        is_fully_qualified = (
            safety_decision == "QUALIFIED"
            and analysis_status == "COMPLETE"
            and not hard_reject
            and safety_score >= minimum_safety
        )

        if hard_reject or safety_decision == "REJECTED":
            new_state = "REJECTED"
            reason = (
                "Safety Engine a rejeté le token"
                if not hard_reject
                else "Blocage critique du Safety Engine"
            )

            if row["candidate_id"]:
                connection.execute(
                    """
                    UPDATE qualification_candidates
                    SET state = ?, safety_score = ?,
                        qualification_score = ?,
                        analysis_status = ?, decision = ?,
                        reason = ?, updated_at = ?
                    WHERE mint = ?
                    """,
                    (
                        new_state,
                        safety_score,
                        safety_score,
                        analysis_status,
                        safety_decision,
                        reason,
                        now_iso(),
                        mint,
                    ),
                )
            else:
                connection.execute(
                    """
                    INSERT INTO qualification_candidates (
                        launch_id, mint, symbol, token_name,
                        creator, bonding_curve, created_at,
                        first_qualified_at, last_sample_at,
                        ready_at, state, safety_score,
                        qualification_score, observation_samples,
                        stable_samples, initial_progress_pct,
                        current_progress_pct, progress_delta_pct,
                        initial_price_sol, current_price_sol,
                        price_change_pct, min_safety_score,
                        max_safety_score, creator_launch_count,
                        analysis_status, decision, reason,
                        position_id, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, NULL,
                            ?, ?, ?, 0, 0, ?, ?, 0, ?, ?, 0,
                            ?, ?, ?, ?, ?, ?, NULL, ?)
                    """,
                    (
                        row["id"],
                        mint,
                        symbol,
                        row["name"],
                        row["creator"],
                        curve_address,
                        row["detected_at"],
                        now_iso(),
                        new_state,
                        safety_score,
                        safety_score,
                        progress,
                        progress,
                        curve_price,
                        curve_price,
                        safety_score,
                        safety_score,
                        creator_count,
                        analysis_status,
                        safety_decision,
                        reason,
                        now_iso(),
                    ),
                )

            record_transition(
                connection,
                mint,
                symbol,
                previous_state,
                new_state,
                safety_score,
                reason,
            )
            continue

        if not is_fully_qualified:
            new_state = "PAUSED"
            reason = (
                "En attente d'une analyse Safety complète et qualifiée"
            )

            if row["candidate_id"]:
                connection.execute(
                    """
                    UPDATE qualification_candidates
                    SET first_qualified_at = NULL,
                        last_sample_at = ?,
                        ready_at = NULL,
                        state = ?,
                        safety_score = ?,
                        qualification_score = ?,
                        observation_samples = 0,
                        stable_samples = 0,
                        initial_progress_pct = ?,
                        current_progress_pct = ?,
                        progress_delta_pct = 0,
                        initial_price_sol = ?,
                        current_price_sol = ?,
                        price_change_pct = 0,
                        min_safety_score = ?,
                        max_safety_score = ?,
                        creator_launch_count = ?,
                        analysis_status = ?,
                        decision = ?,
                        reason = ?,
                        updated_at = ?
                    WHERE mint = ?
                    """,
                    (
                        now_iso(),
                        new_state,
                        safety_score,
                        safety_score,
                        progress,
                        progress,
                        curve_price,
                        curve_price,
                        safety_score,
                        safety_score,
                        creator_count,
                        analysis_status,
                        safety_decision,
                        reason,
                        now_iso(),
                        mint,
                    ),
                )
            else:
                connection.execute(
                    """
                    INSERT INTO qualification_candidates (
                        launch_id, mint, symbol, token_name,
                        creator, bonding_curve, created_at,
                        first_qualified_at, last_sample_at,
                        ready_at, state, safety_score,
                        qualification_score, observation_samples,
                        stable_samples, initial_progress_pct,
                        current_progress_pct, progress_delta_pct,
                        initial_price_sol, current_price_sol,
                        price_change_pct, min_safety_score,
                        max_safety_score, creator_launch_count,
                        analysis_status, decision, reason,
                        position_id, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, NULL,
                            ?, ?, ?, 0, 0, ?, ?, 0, ?, ?, 0,
                            ?, ?, ?, ?, ?, ?, NULL, ?)
                    """,
                    (
                        row["id"],
                        mint,
                        symbol,
                        row["name"],
                        row["creator"],
                        curve_address,
                        row["detected_at"],
                        now_iso(),
                        new_state,
                        safety_score,
                        safety_score,
                        progress,
                        progress,
                        curve_price,
                        curve_price,
                        safety_score,
                        safety_score,
                        creator_count,
                        analysis_status,
                        safety_decision,
                        reason,
                        now_iso(),
                    ),
                )

            record_transition(
                connection,
                mint,
                symbol,
                previous_state,
                new_state,
                safety_score,
                reason,
            )
            continue

        first_qualified = parse_datetime(
            row["first_qualified_at"]
        )
        last_sample = parse_datetime(row["last_sample_at"])

        if first_qualified is None:
            first_qualified = current_time
            initial_progress = progress
            initial_price = curve_price
            samples = 1
            stable_samples = 1
        else:
            initial_progress = to_float(
                row["initial_progress_pct"],
                progress,
            )
            initial_price = to_float(
                row["initial_price_sol"],
                curve_price,
            )
            samples = to_int(row["observation_samples"], 0)
            stable_samples = to_int(row["stable_samples"], 0)

            sample_due = (
                last_sample is None
                or (current_time - last_sample).total_seconds() >= 5
            )
            if sample_due:
                samples += 1
                previous_progress = to_float(
                    row["current_progress_pct"],
                    initial_progress,
                )
                curve_is_stable = (
                    bool(curve.get("valid"))
                    and not bool(curve.get("complete"))
                    and progress >= previous_progress - 0.15
                    and progress >= initial_progress - 0.15
                    and safety_score >= minimum_safety
                )
                if curve_is_stable:
                    stable_samples += 1

        progress_delta = (
            progress - initial_progress
            if progress >= 0 and initial_progress >= 0
            else 0.0
        )
        price_change = (
            (curve_price / initial_price - 1.0) * 100.0
            if curve_price > 0 and initial_price > 0
            else 0.0
        )
        q_score = qualification_score(
            safety_score=safety_score,
            progress_delta=progress_delta,
            stable_samples=stable_samples,
            creator_launch_count=creator_count,
            price_change_pct=price_change,
        )

        observation_age = (
            current_time - first_qualified
        ).total_seconds()

        stable_ratio = (
            stable_samples / max(samples, 1)
        )
        observed_min_safety = min(
            to_float(
                row["min_safety_score"],
                safety_score,
            ),
            safety_score,
        )

        safety_assessed_at = parse_datetime(
            row["safety_assessed_at"]
        )
        safety_age = (
            (current_time - safety_assessed_at).total_seconds()
            if safety_assessed_at
            else float("inf")
        )

        fast_track = (
            progress_delta >= fast_progress_delta
            and 0 <= price_change <= fast_max_price_change
            and stable_ratio >= 0.85
            and samples >= minimum_samples
        )
        required_observation_seconds = (
            fast_observation_seconds
            if fast_track
            else standard_observation_seconds
        )

        checks = {
            "observation": (
                observation_age >= required_observation_seconds
            ),
            "samples": samples >= minimum_samples,
            "stability": stable_ratio >= minimum_stable_ratio,
            "curve": bool(curve.get("valid")),
            "active": not bool(curve.get("complete")),
            "progress": minimum_progress <= progress <= maximum_progress,
            "delta": progress_delta >= minimum_delta,
            "price": abs(price_change) <= maximum_price_change,
            "safety": safety_score >= minimum_safety,
            "safety_floor": observed_min_safety >= minimum_safety,
            "safety_fresh": safety_age <= maximum_safety_age,
            "qualification": q_score >= minimum_qualification_score,
        }

        if all(checks.values()):
            new_state = "READY"
            ready_at = (
                row["ready_at"]
                if row["ready_at"]
                else now_iso()
            )
            reason = (
                "Observation terminée : candidat autorisé "
                "pour une position paper"
            )
        else:
            new_state = "OBSERVATION"
            ready_at = None
            missing = [
                name for name, passed in checks.items()
                if not passed
            ]
            reason = (
                "Contrôles restants : "
                + ", ".join(missing)
            )

        if row["candidate_id"]:
            connection.execute(
                """
                UPDATE qualification_candidates
                SET first_qualified_at = ?,
                    last_sample_at = ?,
                    ready_at = ?,
                    state = ?,
                    safety_score = ?,
                    qualification_score = ?,
                    observation_samples = ?,
                    stable_samples = ?,
                    initial_progress_pct = ?,
                    current_progress_pct = ?,
                    progress_delta_pct = ?,
                    initial_price_sol = ?,
                    current_price_sol = ?,
                    price_change_pct = ?,
                    min_safety_score = ?,
                    max_safety_score = ?,
                    creator_launch_count = ?,
                    analysis_status = ?,
                    decision = ?,
                    reason = ?,
                    updated_at = ?
                WHERE mint = ?
                """,
                (
                    first_qualified.isoformat(),
                    now_iso(),
                    ready_at,
                    new_state,
                    safety_score,
                    q_score,
                    samples,
                    stable_samples,
                    initial_progress,
                    progress,
                    progress_delta,
                    initial_price,
                    curve_price,
                    price_change,
                    min(
                        to_float(
                            row["min_safety_score"],
                            safety_score,
                        ),
                        safety_score,
                    ),
                    max(
                        to_float(
                            row["max_safety_score"],
                            safety_score,
                        ),
                        safety_score,
                    ),
                    creator_count,
                    analysis_status,
                    safety_decision,
                    reason,
                    now_iso(),
                    mint,
                ),
            )
        else:
            connection.execute(
                """
                INSERT INTO qualification_candidates (
                    launch_id, mint, symbol, token_name,
                    creator, bonding_curve, created_at,
                    first_qualified_at, last_sample_at,
                    ready_at, state, safety_score,
                    qualification_score, observation_samples,
                    stable_samples, initial_progress_pct,
                    current_progress_pct, progress_delta_pct,
                    initial_price_sol, current_price_sol,
                    price_change_pct, min_safety_score,
                    max_safety_score, creator_launch_count,
                    analysis_status, decision, reason,
                    position_id, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)
                """,
                (
                    row["id"],
                    mint,
                    symbol,
                    row["name"],
                    row["creator"],
                    curve_address,
                    row["detected_at"],
                    first_qualified.isoformat(),
                    now_iso(),
                    ready_at,
                    new_state,
                    safety_score,
                    q_score,
                    samples,
                    stable_samples,
                    initial_progress,
                    progress,
                    progress_delta,
                    initial_price,
                    curve_price,
                    price_change,
                    safety_score,
                    safety_score,
                    creator_count,
                    analysis_status,
                    safety_decision,
                    reason,
                    now_iso(),
                ),
            )

        record_transition(
            connection,
            mint,
            symbol,
            previous_state,
            new_state,
            q_score,
            reason,
        )


def update_open_positions(
    connection: sqlite3.Connection,
    positions: list[sqlite3.Row],
    curves: dict[str, dict[str, Any]],
    config: dict[str, Any],
    cash: float,
    realized_total: float,
) -> tuple[float, float]:
    fee_bps = int(config["bonding_curve_fee_bps"])
    stop_loss = float(config["radar_stop_loss_pct"])
    take_profit = float(config["radar_take_profit_pct"])
    break_even_trigger = float(
        config["radar_break_even_trigger_pct"]
    )
    break_even_floor = float(
        config["radar_break_even_floor_pct"]
    )
    max_holding = float(
        config["radar_max_holding_minutes"]
    )
    exit_fee = float(config["radar_exit_fee_sol"])

    for position in positions:
        curve_address = str(
            position["bonding_curve_address"]
            or position["bonding_curve"]
            or ""
        )
        curve = curves.get(curve_address)

        if not curve or not curve.get("valid"):
            continue

        tokens = float(position["tokens_received"])
        sell_value, impact = constant_product_sell_quote(
            curve,
            tokens,
            fee_bps,
        )

        if sell_value <= 0:
            sell_value = to_float(
                position["current_value_sol"],
                0.0,
            )

        entry_total = (
            to_float(position["entry_sol"])
            + to_float(position["entry_fees_sol"])
        )
        pnl_pct = (
            (sell_value - entry_total)
            / entry_total
            * 100.0
            if entry_total > 0
            else 0.0
        )

        risk_state = connection.execute(
            """
            SELECT *
            FROM position_risk_state
            WHERE position_id = ?
            """,
            (position["id"],),
        ).fetchone()

        previous_peak = to_float(
            risk_state["peak_pnl_pct"]
            if risk_state
            else pnl_pct,
            pnl_pct,
        )
        peak_pnl_pct = max(previous_peak, pnl_pct)
        break_even_armed = bool(
            risk_state["break_even_armed"]
            if risk_state
            else False
        ) or peak_pnl_pct >= break_even_trigger
        active_stop_pct = (
            break_even_floor
            if break_even_armed
            else stop_loss
        )

        connection.execute(
            """
            INSERT INTO position_risk_state (
                position_id, peak_pnl_pct,
                break_even_armed, active_stop_pct,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(position_id) DO UPDATE SET
                peak_pnl_pct = excluded.peak_pnl_pct,
                break_even_armed = excluded.break_even_armed,
                active_stop_pct = excluded.active_stop_pct,
                updated_at = excluded.updated_at
            """,
            (
                position["id"],
                peak_pnl_pct,
                int(break_even_armed),
                active_stop_pct,
                now_iso(),
            ),
        )

        opened_at = parse_datetime(position["opened_at"])
        age_minutes = (
            (now_utc() - opened_at).total_seconds() / 60.0
            if opened_at
            else 0.0
        )

        safety = connection.execute(
            """
            SELECT decision, hard_reject, safety_score
            FROM safety_assessments
            WHERE mint = ?
            """,
            (position["token_mint"],),
        ).fetchone()

        exit_reason: str | None = None
        if safety and (
            safety["decision"] == "REJECTED"
            or bool(safety["hard_reject"])
        ):
            exit_reason = "SAFETY_DOWNGRADE"
        elif (
            break_even_armed
            and pnl_pct <= break_even_floor
        ):
            exit_reason = "BREAK_EVEN_STOP"
        elif pnl_pct <= stop_loss:
            exit_reason = "STOP_LOSS"
        elif pnl_pct >= take_profit:
            exit_reason = "TAKE_PROFIT"
        elif age_minutes >= max_holding:
            exit_reason = "TIME_EXIT"
        elif bool(curve.get("complete")):
            exit_reason = "CURVE_COMPLETE"

        current_price_sol = to_float(curve.get("price_sol"))
        current_price_usd = 0.0

        sol_row = connection.execute(
            "SELECT value FROM bot_state WHERE key='sol_price_usd'"
        ).fetchone()
        if sol_row:
            current_price_usd = (
                current_price_sol
                * to_float(sol_row["value"])
            )

        connection.execute(
            """
            UPDATE positions
            SET current_price_sol = ?,
                current_price_usd = ?,
                current_value_sol = ?
            WHERE id = ?
            """,
            (
                current_price_sol,
                current_price_usd,
                sell_value,
                position["id"],
            ),
        )

        if exit_reason is None:
            continue

        exit_sol = max(0.0, sell_value - exit_fee)
        pnl_sol = exit_sol - entry_total
        pnl_pct_final = (
            pnl_sol / entry_total * 100.0
            if entry_total > 0
            else 0.0
        )
        cash += exit_sol
        realized_total += pnl_sol

        connection.execute(
            """
            UPDATE positions
            SET closed_at = ?,
                exit_sol = ?,
                exit_price_sol = ?,
                current_value_sol = ?,
                exit_fees_sol = ?,
                realized_pnl_sol = ?,
                realized_pnl_pct = ?,
                exit_reason = ?,
                status = 'CLOSED'
            WHERE id = ?
            """,
            (
                now_iso(),
                exit_sol,
                current_price_sol,
                exit_sol,
                exit_fee,
                pnl_sol,
                pnl_pct_final,
                exit_reason,
                position["id"],
            ),
        )

        connection.execute(
            """
            INSERT INTO paper_orders (
                timestamp, token_mint, token_name,
                symbol, market_mode, side,
                requested_sol, expected_output,
                simulated_output, price_impact_pct,
                extra_slippage_pct, latency_ms,
                status, failure_reason
            )
            VALUES (?, ?, ?, ?, 'RADAR_BONDING', 'SELL',
                    ?, ?, ?, ?, ?, 950, 'FILLED', NULL)
            """,
            (
                now_iso(),
                position["token_mint"],
                position["token_name"],
                position["symbol"],
                sell_value,
                sell_value,
                exit_sol,
                impact,
                impact,
            ),
        )

        connection.execute(
            """
            INSERT INTO signals (
                timestamp, token_mint, token_name,
                symbol, lifecycle_state,
                decision, strategy, score,
                reasons_json
            )
            VALUES (?, ?, ?, ?, ?, 'SELL', ?, ?, ?)
            """,
            (
                now_iso(),
                position["token_mint"],
                position["token_name"],
                position["symbol"],
                (
                    "CURVE_COMPLETE"
                    if curve.get("complete")
                    else "BONDING"
                ),
                STRATEGY,
                to_float(
                    safety["safety_score"]
                    if safety
                    else 0
                ),
                json.dumps(
                    [
                        exit_reason,
                        f"PnL paper {pnl_pct_final:+.2f}%",
                    ],
                    ensure_ascii=False,
                ),
            ),
        )

        candidate = connection.execute(
            """
            SELECT state, qualification_score
            FROM qualification_candidates
            WHERE mint = ?
            """,
            (position["token_mint"],),
        ).fetchone()

        previous_state = (
            candidate["state"]
            if candidate
            else "PAPER_POSITION"
        )
        qualification_value = to_float(
            candidate["qualification_score"]
            if candidate
            else 0
        )

        connection.execute(
            """
            UPDATE qualification_candidates
            SET state = 'CLOSED',
                reason = ?,
                updated_at = ?
            WHERE mint = ?
            """,
            (
                f"Position clôturée : {exit_reason}",
                now_iso(),
                position["token_mint"],
            ),
        )
        record_transition(
            connection,
            position["token_mint"],
            position["symbol"],
            previous_state,
            "CLOSED",
            qualification_value,
            f"Position clôturée : {exit_reason}",
        )

    return cash, realized_total


def open_ready_positions(
    connection: sqlite3.Connection,
    curves: dict[str, dict[str, Any]],
    config: dict[str, Any],
    cash: float,
) -> float:
    position_size = float(config["radar_position_size_sol"])
    max_positions = int(config["radar_max_open_positions"])
    max_exposure = float(
        config["radar_max_total_exposure_sol"]
    )
    cash_reserve = float(
        config["radar_min_cash_reserve_sol"]
    )
    entry_fee = float(config["radar_entry_fee_sol"])
    fee_bps = int(config["bonding_curve_fee_bps"])

    open_rows = connection.execute(
        """
        SELECT *
        FROM positions
        WHERE status = 'OPEN'
        """
    ).fetchall()
    open_count = len(open_rows)
    exposure = sum(
        to_float(row["entry_sol"])
        for row in open_rows
    )
    open_mints = {
        str(row["token_mint"])
        for row in open_rows
    }

    ready = connection.execute(
        """
        SELECT candidates.*, launches.uri
        FROM qualification_candidates candidates
        LEFT JOIN new_launches launches
            ON launches.mint = candidates.mint
        WHERE candidates.state = 'READY'
        ORDER BY
            candidates.qualification_score DESC,
            datetime(candidates.ready_at) ASC
        LIMIT 50
        """
    ).fetchall()

    sol_row = connection.execute(
        "SELECT value FROM bot_state WHERE key='sol_price_usd'"
    ).fetchone()
    sol_price_usd = (
        to_float(sol_row["value"])
        if sol_row
        else 0.0
    )

    for candidate in ready:
        mint = str(candidate["mint"])
        if mint in open_mints:
            continue
        if open_count >= max_positions:
            break
        if exposure + position_size > max_exposure:
            break
        if (
            cash - position_size - entry_fee
            < cash_reserve
        ):
            break

        curve_address = str(
            candidate["bonding_curve"] or ""
        )
        curve = curves.get(curve_address)

        if (
            not curve
            or not curve.get("valid")
            or curve.get("complete")
        ):
            connection.execute(
                """
                UPDATE qualification_candidates
                SET state = 'EXPIRED',
                    reason = ?,
                    updated_at = ?
                WHERE mint = ?
                """,
                (
                    "La bonding curve n'est plus achetable",
                    now_iso(),
                    mint,
                ),
            )
            record_transition(
                connection,
                mint,
                candidate["symbol"],
                "READY",
                "EXPIRED",
                to_float(candidate["qualification_score"]),
                "La bonding curve n'est plus achetable",
            )
            continue

        tokens_received, entry_price, impact = (
            constant_product_buy_quote(
                curve,
                position_size,
                fee_bps,
            )
        )
        if tokens_received <= 0 or entry_price <= 0:
            continue

        current_value, sell_impact = (
            constant_product_sell_quote(
                curve,
                tokens_received,
                fee_bps,
            )
        )
        current_price = to_float(curve["price_sol"])

        cursor = connection.execute(
            """
            INSERT INTO positions (
                token_mint, token_name, symbol,
                market_mode, lifecycle_at_entry,
                bonding_curve_address,
                pair_address, source_url,
                opened_at, closed_at,
                entry_sol, exit_sol,
                tokens_received, entry_price_sol,
                entry_price_usd, exit_price_sol,
                current_price_sol, current_price_usd,
                current_value_sol,
                entry_liquidity_usd,
                entry_market_cap_usd,
                entry_bonding_progress_pct,
                entry_fees_sol, exit_fees_sol,
                realized_pnl_sol, realized_pnl_pct,
                strategy, exit_reason, status
            )
            VALUES (?, ?, ?, 'RADAR_BONDING', 'BONDING',
                    ?, NULL, ?, ?, NULL,
                    ?, NULL, ?, ?, ?, NULL,
                    ?, ?, ?, 0, NULL, ?, ?, 0,
                    NULL, NULL, ?, NULL, 'OPEN')
            """,
            (
                mint,
                candidate["token_name"],
                candidate["symbol"],
                curve_address,
                (
                    f"https://pump.fun/coin/{mint}"
                ),
                now_iso(),
                position_size,
                tokens_received,
                entry_price,
                (
                    entry_price * sol_price_usd
                    if sol_price_usd
                    else None
                ),
                current_price,
                (
                    current_price * sol_price_usd
                    if sol_price_usd
                    else None
                ),
                current_value,
                candidate["current_progress_pct"],
                entry_fee,
                STRATEGY,
            ),
        )
        position_id = int(cursor.lastrowid)

        initial_entry_total = position_size + entry_fee
        initial_pnl_pct = (
            (current_value - initial_entry_total)
            / initial_entry_total
            * 100.0
            if initial_entry_total > 0
            else 0.0
        )
        connection.execute(
            """
            INSERT INTO position_risk_state (
                position_id, peak_pnl_pct,
                break_even_armed, active_stop_pct,
                updated_at
            )
            VALUES (?, ?, 0, ?, ?)
            """,
            (
                position_id,
                initial_pnl_pct,
                float(config["radar_stop_loss_pct"]),
                now_iso(),
            ),
        )

        connection.execute(
            """
            INSERT INTO paper_orders (
                timestamp, token_mint, token_name,
                symbol, market_mode, side,
                requested_sol, expected_output,
                simulated_output, price_impact_pct,
                extra_slippage_pct, latency_ms,
                status, failure_reason
            )
            VALUES (?, ?, ?, ?, 'RADAR_BONDING', 'BUY',
                    ?, ?, ?, ?, ?, 950, 'FILLED', NULL)
            """,
            (
                now_iso(),
                mint,
                candidate["token_name"],
                candidate["symbol"],
                position_size,
                tokens_received,
                tokens_received,
                impact,
                max(impact, sell_impact),
            ),
        )

        connection.execute(
            """
            INSERT INTO signals (
                timestamp, token_mint, token_name,
                symbol, lifecycle_state,
                decision, strategy, score,
                reasons_json
            )
            VALUES (?, ?, ?, ?, 'BONDING', 'BUY', ?, ?, ?)
            """,
            (
                now_iso(),
                mint,
                candidate["token_name"],
                candidate["symbol"],
                STRATEGY,
                to_float(candidate["qualification_score"]),
                json.dumps(
                    [
                        "Safety Engine QUALIFIED",
                        (
                            f"Observation "
                            f"{candidate['observation_samples']} échantillons"
                        ),
                        (
                            f"Progression "
                            f"{to_float(candidate['progress_delta_pct']):+.2f}%"
                        ),
                        (
                            f"Qualification "
                            f"{to_float(candidate['qualification_score']):.1f}/100"
                        ),
                    ],
                    ensure_ascii=False,
                ),
            ),
        )

        connection.execute(
            """
            UPDATE qualification_candidates
            SET state = 'PAPER_POSITION',
                position_id = ?,
                reason = ?,
                updated_at = ?
            WHERE mint = ?
            """,
            (
                position_id,
                "Position paper automatique ouverte",
                now_iso(),
                mint,
            ),
        )
        record_transition(
            connection,
            mint,
            candidate["symbol"],
            "READY",
            "PAPER_POSITION",
            to_float(candidate["qualification_score"]),
            "Position paper automatique ouverte",
        )

        cash -= position_size + entry_fee
        exposure += position_size
        open_count += 1
        open_mints.add(mint)

    return cash


def save_portfolio_snapshot(
    connection: sqlite3.Connection,
    cash: float,
    realized_total: float,
) -> None:
    positions = connection.execute(
        """
        SELECT *
        FROM positions
        WHERE status = 'OPEN'
        """
    ).fetchall()

    open_value = sum(
        to_float(row["current_value_sol"])
        for row in positions
    )
    entry_cost = sum(
        to_float(row["entry_sol"])
        + to_float(row["entry_fees_sol"])
        for row in positions
    )
    unrealized = open_value - entry_cost
    equity = cash + open_value

    connection.execute(
        """
        INSERT INTO portfolio_snapshots (
            timestamp, cash_sol,
            open_positions_value_sol,
            equity_sol, realized_pnl_sol,
            unrealized_pnl_sol
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            now_iso(),
            cash,
            open_value,
            equity,
            realized_total,
            unrealized,
        ),
    )

    connection.execute(
        """
        DELETE FROM portfolio_snapshots
        WHERE id NOT IN (
            SELECT id
            FROM portfolio_snapshots
            ORDER BY id DESC
            LIMIT 15000
        )
        """
    )


def update_pipeline_state(
    connection: sqlite3.Connection,
    status: str,
    error_text: str = "",
) -> None:
    counts = {
        row["state"]: int(row["count"])
        for row in connection.execute(
            """
            SELECT state, COUNT(*) AS count
            FROM qualification_candidates
            GROUP BY state
            """
        ).fetchall()
    }

    write_state(connection, "qualification_status", status)
    write_state(
        connection,
        "qualification_last_cycle",
        now_iso(),
    )
    write_state(
        connection,
        "qualification_last_error",
        error_text[:500],
    )
    write_state(
        connection,
        "qualification_observation_count",
        str(counts.get("OBSERVATION", 0)),
    )
    write_state(
        connection,
        "qualification_ready_count",
        str(counts.get("READY", 0)),
    )
    write_state(
        connection,
        "qualification_open_count",
        str(counts.get("PAPER_POSITION", 0)),
    )


def run_cycle(
    rpc_client: httpx.Client,
    config: dict[str, Any],
) -> None:
    sources = load_sources()
    open_positions = load_open_pipeline_positions()

    curve_addresses = {
        str(row["bonding_curve"])
        for row in sources
        if row["bonding_curve"]
    }
    curve_addresses.update(
        str(row["bonding_curve_address"] or row["bonding_curve"])
        for row in open_positions
        if row["bonding_curve_address"] or row["bonding_curve"]
    )

    accounts = fetch_curve_accounts(
        rpc_client,
        sorted(curve_addresses),
    )
    curves = {
        address: decode_curve(account)
        for address, account in accounts.items()
    }

    with connect_db() as connection:
        connection.execute("BEGIN IMMEDIATE")

        synchronize_candidates(
            connection,
            sources,
            curves,
            config,
        )

        portfolio = latest_portfolio(connection)
        cash = float(portfolio["cash_sol"])
        realized_total = float(
            portfolio["realized_pnl_sol"]
        )

        live_positions = connection.execute(
            """
            SELECT positions.*, launches.bonding_curve
            FROM positions
            LEFT JOIN new_launches launches
                ON launches.mint = positions.token_mint
            WHERE positions.status = 'OPEN'
              AND positions.strategy = ?
            ORDER BY positions.id
            """,
            (STRATEGY,),
        ).fetchall()

        cash, realized_total = update_open_positions(
            connection,
            live_positions,
            curves,
            config,
            cash,
            realized_total,
        )

        cash = open_ready_positions(
            connection,
            curves,
            config,
            cash,
        )

        save_portfolio_snapshot(
            connection,
            cash,
            realized_total,
        )
        update_pipeline_state(
            connection,
            "RUNNING",
        )
        connection.commit()


def main() -> None:
    if not DB_PATH.exists():
        print("Base absente. Lance 02_REINITIALISER_1_SOL.bat.")
        return

    config = load_json(CONFIG_PATH)
    if not config.get("qualification_enabled", True):
        print("Le Qualification Pipeline est désactivé.")
        return

    rpc_url = os.getenv(
        "SOLANA_RPC_URL",
        str(config.get("solana_rpc_url")),
    )
    cycle_seconds = float(
        config["qualification_scan_seconds"]
    )

    acquire_lock()

    print("=" * 76)
    print("SOLPULSE V10.1 — STRATEGY ENGINE")
    print("=" * 76)
    print(f"RPC : {rpc_url}")
    print(
        f"Observation minimale : "
        f"{config['qualification_observation_seconds']} secondes"
    )
    print(
        f"Échantillons requis : "
        f"{config['qualification_min_samples']}"
    )
    print(
        f"Position paper : "
        f"{config['radar_position_size_sol']} SOL"
    )
    print("Aucune transaction réelle.")
    print()

    rpc_client = httpx.Client(
        base_url=rpc_url,
        timeout=httpx.Timeout(20.0),
    )

    try:
        while running:
            started = time.monotonic()
            LOCK_PATH.touch(exist_ok=True)

            try:
                run_cycle(rpc_client, config)

                with connect_db() as connection:
                    counts = {
                        row["state"]: int(row["count"])
                        for row in connection.execute(
                            """
                            SELECT state, COUNT(*) AS count
                            FROM qualification_candidates
                            GROUP BY state
                            """
                        ).fetchall()
                    }
                    portfolio = latest_portfolio(connection)
                    open_count = int(
                        connection.execute(
                            """
                            SELECT COUNT(*)
                            FROM positions
                            WHERE status = 'OPEN'
                            """
                        ).fetchone()[0]
                    )

                print(
                    f"{datetime.now().strftime('%H:%M:%S')} | "
                    f"{counts} | "
                    f"Équité {float(portfolio['equity_sol']):.4f} SOL | "
                    f"Positions {open_count}"
                )

            except KeyboardInterrupt:
                break
            except Exception as error:
                message = str(error)
                print(f"Erreur pipeline : {message}")

                try:
                    with connect_db() as connection:
                        update_pipeline_state(
                            connection,
                            "ERROR",
                            message,
                        )
                        connection.commit()
                except Exception:
                    pass

            elapsed = time.monotonic() - started
            time.sleep(max(1.0, cycle_seconds - elapsed))

    finally:
        rpc_client.close()
        try:
            with connect_db() as connection:
                update_pipeline_state(
                    connection,
                    "STOPPED",
                )
                connection.commit()
        except Exception:
            pass

        release_lock()
        print("Strategy Engine V10.1 arrêté proprement.")


if __name__ == "__main__":
    main()

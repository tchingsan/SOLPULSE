Les bases paper-smoke-*.db sont créées uniquement par 06_TESTER_ACHAT_PAPER_V12_2.bat.
Elles sont indépendantes de data\trading.db et sont volontairement conservées pour éviter WinError 32 sous Windows.
